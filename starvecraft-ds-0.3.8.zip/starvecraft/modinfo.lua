name = "StarveCraft"
description = "Minecraft invades Don't Starve.\n\nMinecraft renders original game sprites and receives player input while Don't Starve runs the paired world simulation."
author = "StarveCraft"
version = "0.3.8"
forumthread = ""

api_version = 6

dont_starve_compatible = true
reign_of_giants_compatible = true
shipwrecked_compatible = false
hamlet_compatible = false

restart_required = false
