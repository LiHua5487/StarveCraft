local function fn()
    local inst=CreateEntity()
    inst.entity:AddTransform();inst.entity:Hide()
    inst:AddTag("NOCLICK");inst:AddTag("sc_itemholder")
    inst.persists=true;inst:AddComponent("container")
    local container=inst.components.container
    container:SetNumSlots(64);container.canbeopened=false
    function container:CanTakeItemInSlot(item) return item and item.components.inventoryitem~=nil end
    local store=require("starvecraft/inventory")
    store.BindHolder(inst)
    inst.OnPreLoad=function(self,data) self.components.container:SetNumSlots(math.max(64,data and data.sc_slots or 64)) end
    inst.OnSave=function(self,data) data.sc_holder=self.sc_holder;data.sc_slots=self.components.container.numslots end
    inst.OnLoad=function(self,data) if data and data.sc_holder then store.BindHolder(self,data.sc_holder) end end
    return inst
end
return Prefab("sc_itemholder",fn)
