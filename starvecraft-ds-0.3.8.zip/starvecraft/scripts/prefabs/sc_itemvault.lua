local function fn()
    local inst=CreateEntity()
    inst.entity:AddTransform()
    inst:AddTag("NOCLICK")
    inst:AddTag("sc_itemvault")
    inst.entity:Hide()
    inst.persists=true
    inst:AddComponent("container")
    local container=inst.components.container
    container:SetNumSlots(64)
    container.canbeopened=false
    -- Internal storage also holds backpacks; normal containers retain their native restrictions.
    function container:CanTakeItemInSlot(item) return item and item.components.inventoryitem~=nil end
    require("starvecraft/inventory").BindVault(inst)
    inst.OnPreLoad=function(self,data)
        local slots=data and data.sc_slots or 64
        self.components.container:SetNumSlots(math.max(64,slots))
    end
    inst.OnSave=function(self,data)
        data.sc_slots=self.components.container.numslots
        require("starvecraft/inventory").SaveVault(data)
    end
    inst.OnLoad=function(self,data) require("starvecraft/inventory").LoadVault(data) end
    return inst
end
return Prefab("sc_itemvault",fn)
