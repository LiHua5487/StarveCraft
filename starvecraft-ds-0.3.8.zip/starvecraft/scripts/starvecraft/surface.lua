-- Query the native locomotor; no road/creep movement rules are reproduced here.
local M={speed=1}
local next_check=0
local stream=require("starvecraft/scenestream")
local bridge=require("starvecraft/mcbridge")
local providers,road_chunks,loaded={},{},{}
local radii=setmetatable({}, {__mode="k"})
local pending_radii=setmetatable({}, {__mode="k"})
local stamp,revision="",0
local regions={}
local candidates={}
local finished
local job
local cached,cache_key
local function AddArea(out,x0,z0,x1,z1)
    for x=math.floor(x0/16),math.floor(x1/16) do for z=math.floor(z0/16),math.floor(z1/16) do out[x..":"..z]={x,z} end end
end
function M.Observe()
    local probe=CreateEntity();local api=getmetatable(probe.entity).__index;local add=api.AddGroundCreepEntity;probe:Remove()
    local hooked=false
    api.AddGroundCreepEntity=function(self,...)
        local result=add(self,...);local inst=Ents[self:GetGUID()];if inst then providers[inst.GUID]=inst end
        if not hooked then
            hooked=true;local methods=getmetatable(result).__index;local set=methods.SetRadius
            methods.SetRadius=function(entity,r,...)
                local result=set(entity,r,...)
                -- Let the native coverage map finish the setter's simulation frame before invalidating its visual cache.
                pending_radii[entity]={radius=r,after=GetTime()+GetTickTime()}
                return result
            end
        end
        return result
    end
end
function M.Install(player)
    for _,road in pairs(Roads or {}) do for i=3,#road do
        local a,b=road[i-1],road[i]
        AddArea(road_chunks,math.min(a[1],b[1])-16,math.min(a[2],b[2])-16,math.max(a[1],b[1])+16,math.max(a[2],b[2])+16)
    end end
    candidates=road_chunks
    player:DoPeriodicTask(GetTickTime(),function()
        if not require("starvecraft/link").Active() then return end
        local px,py,pz=player.Transform:GetWorldPosition();local reach=bridge.pose and bridge.pose.view_distance or 32
        local work_key=math.floor(px/16)..":"..math.floor(pz/16)..":"..reach..":"..revision
        if finished==work_key then return end
        local nearest,distance
        if job and (job.stamp~=stamp or math.abs(job.x0+8-px)>reach+16 or math.abs(job.z0+8-pz)>reach+16) then job=nil end
        if not job then
        for key,cell in pairs(candidates) do
            local dx,dz=cell[1]*16+8-px,cell[2]*16+8-pz;local d=dx*dx+dz*dz
            if math.abs(dx)<=reach+16 and math.abs(dz)<=reach+16 and (not loaded[key] or loaded[key].stamp~=stamp) and (not distance or d<distance) then nearest={key,cell};distance=d end
        end
        if not nearest then finished=work_key;return end
        local key,cell=nearest[1],nearest[2];local x0,z0=cell[1]*16,cell[2]*16
        local creep=false
        for _,area in ipairs(regions) do if math.abs(area[1]-x0-8)<area[3]+12 and math.abs(area[2]-z0-8)<area[3]+12 then creep=true;break end end
        job={key=key,x0=x0,z0=z0,z=z0,creep=creep,stamp=stamp,patches={}}
        end
        local patches,x0,z0,creep=job.patches,job.x0,job.z0,job.creep
        local world=GetWorld()
        -- Native IsOnRoad is expensive; visual sampling gets at most about 1 ms per simulation tick.
        local deadline=os.clock()+.001
        repeat
            local z=job.z
            local start,kind
            local function flush(x) if kind then patches[#patches+1]={start,z,x-start,kind} end end
            for x=x0,x0+16,.5 do
                local value
                if x<x0+16 then
                    if creep and world.GroundCreep:OnCreep(x+.25,0,z+.25) then value="web"
                    elseif road_chunks[job.key] and RoadManager and RoadManager:IsOnRoad(x+.25,0,z+.25) then value="road" end
                end
                if value~=kind then flush(x);start=x;kind=value end
            end
            job.z=z+.5
        until job.z==z0+16 or os.clock()>=deadline
        if job.z==z0+16 then loaded[job.key]={stamp=stamp,patches=patches};revision=revision+1;job=nil end
    end)
end
function M.Update(player)
    local motor=player.components.locomotor
    if motor and GetTime()>=next_check then
        next_check=GetTime()+.5
        if motor.enablegroundspeedmultiplier and (not bridge.pose or bridge.pose.moving~=false) then
            motor:UpdateGroundSpeedMultiplier()
        end
        M.speed=motor.enablegroundspeedmultiplier and motor.groundspeedmultiplier or 1
        local parts,new_regions={},{}
        for component,change in pairs(pending_radii) do
            if GetTime()>=change.after then radii[component]=change.radius;pending_radii[component]=nil end
        end
        for id,inst in pairs(providers) do
            if not inst:IsValid() then providers[id]=nil
            else
                local radius=radii[inst.GroundCreepEntity]
                if radius then
                    local x,y,z=inst.Transform:GetWorldPosition()
                    local ready=radius>0 and GetWorld().GroundCreep:OnCreep(x,0,z)
                    parts[#parts+1]=id..":"..x..":"..z..":"..radius..":"..tostring(ready)
                    if ready then new_regions[#new_regions+1]={x,z,radius} end
                end
            end
        end
        table.sort(parts);local key=table.concat(parts,";")
        if key~=stamp then
            stamp=key;regions=new_regions;revision=revision+1;candidates={}
            for id,value in pairs(road_chunks) do candidates[id]=value end
            for _,area in ipairs(regions) do AddArea(candidates,area[1]-area[3]-4,area[2]-area[3]-4,area[1]+area[3]+4,area[2]+area[3]+4) end
        end
    elseif motor and not motor.enablegroundspeedmultiplier then M.speed=1 end
end
function M.Patches(player)
    local px,py,pz=player.Transform:GetWorldPosition();local reach=bridge.pose and bridge.pose.view_distance or 32
    local origin=bridge.origin;local key=math.floor(px/16)..":"..math.floor(pz/16)..":"..reach..":"..revision..":"..origin.x..":"..origin.z
    if key==cache_key then return cached end
    local result={}
    for _,cell in pairs(loaded) do for _,patch in ipairs(cell.patches) do
        if (cell.stamp==stamp or patch[4]=="road") and math.abs(patch[1]-px)<=reach+16 and math.abs(patch[2]-pz)<=reach+16 then
            result[#result+1]={patch[1]-origin.x,origin.z-patch[2]-.5,patch[3],patch[4]}
        end
    end end
    cached=stream.Immutable(result);cache_key=key;return cached
end
return M
