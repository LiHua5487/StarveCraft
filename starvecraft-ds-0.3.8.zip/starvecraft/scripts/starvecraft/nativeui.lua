-- Export the original container widget tree, including its native animation and callbacks.
local M={}
local json=require("json")
local items=require("starvecraft/items")
local texts=setmetatable({},{__mode="k"})
local order=0
function M.HookWidget(widget)
    local add=widget.AddChild
    function widget:AddChild(child,...)
        order=order+1;child.sc_order=order
        return add(self,child,...)
    end
    for _,name in ipairs({"MoveToFront","MoveToBack"}) do
        local original=widget[name]
        widget[name]=function(self,...)
            order=order+1;self.sc_order=name=="MoveToBack" and -order or order
            return original(self,...)
        end
    end
end
function M.Install()
    local probe=CreateEntity();probe.entity:AddUITransform();probe.entity:AddTextWidget()
    local api=getmetatable(probe.TextWidget).__index
    for _,name in ipairs({"SetFont","SetSize","SetColour"}) do
        local original=api[name]
        api[name]=function(self,...)
            local state=texts[self] or {};texts[self]=state;state[name]={...}
            return original(self,...)
        end
    end
    probe:Remove()
end
function M.Open(inst)
    inst.components.container:Open(GetPlayer())
    M.current=inst
end
function M.HookContainer(container)
    local open=container.Open
    function container:Open(doer,...)
        local result=open(self,doer,...)
        if doer==GetPlayer() then M.current=self.inst end
        return result
    end
end
local function Widget()
    local player=GetPlayer()
    return M.current and M.current:IsValid() and player.HUD.controls.containers[M.current]
end
function M.Snapshot()
    local root=Widget()
    if not root or not root.isopen then return {id=0,nodes={},slots={}} end
    local nodes,slots={},{}
    local origin,scale=root:GetWorldPosition(),root:GetScale()
    local function visit(widget)
        if not widget.shown then return end
        local pos,s=widget:GetWorldPosition(),widget:GetScale()
        local node={x=(pos.x-origin.x)/scale.x,y=(pos.y-origin.y)/scale.y,sx=s.x/scale.x,sy=s.y/scale.y}
        if widget.inst.ImageWidget and widget.texture then
            node.kind="image";node.atlas=items.Path(widget.atlas)
            node.image=not widget.enabled and widget.disabledtex or widget.texture
            node.w,node.h=widget:GetSize()
            local tile=widget.parent
            if tile and tile.item and tile.image==widget then
                local parcel=tile.item.sc_mc_item
                if parcel then node.atlas,node.image=parcel.atlas,parcel.image
                end
            end
        elseif widget.inst.AnimState then
            local art=require("starvecraft/animtrack").Get(widget.inst)
            if art and art.anim~="?" then node.kind="anim";node.art=art;art.files={} end
        elseif widget.inst.TextWidget then
            local st=texts[widget.inst.TextWidget] or {}
            node.kind="text";node.text=widget:GetString();node.font=st.SetFont and st.SetFont[1] or "buttonfont"
            for _,font in ipairs(FONTS) do
                if font.alias==node.font then node.font=font.filename:match("fonts/(.+)%.zip$");break end
            end
            node.size=st.SetSize and st.SetSize[1] or 30;node.colour=st.SetColour or {1,1,1,1}
        end
        if node.kind then table.insert(nodes,node) end
        local children={}
        for child in pairs(widget.children) do table.insert(children,child) end
        table.sort(children,function(a,b) return (a.sc_order or 0)<(b.sc_order or 0) end)
        for _,child in ipairs(children) do visit(child) end
    end
    visit(root)
    for index,slot in ipairs(root.inv) do
        local p=slot:GetWorldPosition()
        table.insert(slots,{index=index,x=(p.x-origin.x)/scale.x,y=(p.y-origin.y)/scale.y})
    end
    local button
    if root.button then
        local p=root.button:GetWorldPosition()
        local w,h=root.button.image:GetSize()
        local s=root.button.image:GetScale()
        button={x=(p.x-origin.x)/scale.x,y=(p.y-origin.y)/scale.y,w=w*s.x/scale.x,h=h*s.y/scale.y,enabled=root.button.enabled}
    end
    return {id=M.current.GUID,nodes=nodes,slots=slots,button=button}
end
function M.Execute(request)
    if type(request)~="table" or type(request.id)~="string" or not request.id:match("^[%w%-]+$") or #request.id>64 then return end
    local player=GetPlayer()
    local receipts=player.components.builder.sc_receipts
    local function reply(result) require("starvecraft/channel").Send("craft_result "..json.encode(result)) end
    if receipts[request.id] then reply(receipts[request.id]);return end
    local root=Widget()
    local result={id=request.id,ok=false,outputs={}}
    if root and root.isopen and root.container and root.container.GUID==request.container and root.container:IsNear(player,3) then
        local container=root.container
        local inv=player.components.inventory
        local equipment=require("starvecraft/equipment")
        local store=require("starvecraft/inventory")
        if request.item then request.item.import_id=request.item.import_id or request.id end
        local source=request.item and equipment.Acquire(request.item)
        if request.item and not source then receipts[request.id]=result;reply(result);return end
        if source then equipment.Detach(source) end
        inv:GiveActiveItem(source)
        local overflow
        if source and source.components.stackable then
            local stack=source.components.stackable
            if stack:StackSize()>stack.maxsize then overflow=stack:Get(stack:StackSize()-stack.maxsize);overflow.sc_mc_origin=source.sc_mc_origin end
        end
        local slot=tonumber(request.slot)
        local invasion=require("starvecraft/invasion")
        invasion.BeginEffects()
        local ok,err=pcall(function()
            if slot and slot==math.floor(slot) and root.inv[slot] then root.inv[slot]:Click(request.split==true)
            elseif request.button and root.button and root.button.enabled then root.button.onclick()
            elseif request.close then root:Close() end
        end)
        local effects=invasion.EndEffects();if next(effects) then result.effects=effects end
        local active=inv:GetActiveItem()
        for _,item in pairs(container.components.container.slots) do item.persists=true;store.Track(item) end
        result.ok=true
        if overflow then
            if active and active.prefab==overflow.prefab and active.components.stackable then
                -- MC allows larger carried stacks; let native Put merge their actual state.
                local stack=active.components.stackable
                local maximum=stack.maxsize
                stack.maxsize=math.max(maximum,stack:StackSize()+overflow.components.stackable:StackSize())
                local merged,remaining=pcall(stack.Put,stack,overflow)
                stack.maxsize=maximum
                if not merged then error(remaining) end
                if remaining then table.insert(result.outputs,store.Keep(remaining)) end
            elseif not active then active=overflow
            else table.insert(result.outputs,store.Keep(overflow)) end
        end
        result.replacement=active and store.Keep(active) or {removed=true,count=0}
        receipts[request.id]=result;reply(result)
        if not ok then error(err) end
        return
    end
    receipts[request.id]=result;reply(result)
end
function M.Close(id)
    local root=Widget()
    if root and root.container and root.container.GUID==tonumber(id) then root:Close() end
end
return M
