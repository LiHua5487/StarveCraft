-- Native teleporters choose the landing point; retain it until MC acknowledges that position.
local M={}
local pending,record,context,serial=nil,nil,"",0
local bridge=require("starvecraft/mcbridge")
local link=require("starvecraft/link")
local function Context()
    local key=link.PairId()..":"..link.McSession()
    if key~=context then context=key;pending=nil;record=nil;serial=0 end
end
function M.Hook(teleporter)
    local teleport=teleporter.Teleport
    function teleporter:Teleport(obj,...)
        local result=teleport(self,obj,...)
        if self.targetTeleporter and obj==GetPlayer() and link.Active() and bridge.pose then
            Context();serial=serial+1
            local x,y,z=obj.Transform:GetWorldPosition();local mx,my,mz=bridge.ToMC(x,y,z)
            record={id=serial,mc_session=link.McSession(),seq=bridge.pose.seq,x=mx,z=mz}
            pending=record
        end
        return result
    end
end
function M.Waiting(pose)
    Context()
    if pending and pose.travel_ack==pending.id and pose.seq>pending.seq
        and (pose.x-pending.x)^2+(pose.z-pending.z)^2<1 then pending=nil end
    return pending~=nil
end
function M.Snapshot() Context();return record or {id=0} end
return M
