-- Acknowledged snapshots: retain missed changes, checkpoint if the reader falls behind.
local M={}
local json=require("json")
local context,previous,metadata,outbox,last_ack="",{},{},{},0
local immutable=setmetatable({}, {__mode="k"})
local sources={}
function M.Immutable(value) immutable[value]=true;return value end
local position={x=true,y=true,z=true}
local playback={percent=true,rotation=true}
local function Same(a,b,skip)
    if a==b then return true end
    if type(a)~="table" or type(b)~="table" then return false end
    for k,v in pairs(a) do if not (skip and skip[k]) and v~=b[k] and not Same(v,b[k],skip==position and k=="art" and playback or nil) then return false end end
    for k in pairs(b) do if not (skip and skip[k]) and a[k]==nil then return false end end
    return true
end
local function Freeze(source,skip)
    if type(source)~="table" then return source end
    local copy={}
    for k,v in pairs(source) do if not (skip and skip[k]) then copy[k]=Freeze(v,skip==position and k=="art" and playback or nil) end end
    return copy
end
function M.Set(entry,target,key,value)
    if target[key]~=value then target[key]=value;entry.revision=entry.revision+1 end
end
function M.Encode(scene,ack,revisions)
    local key=scene.pair..":"..scene.session
    if key~=context then context=key;previous={};metadata={};sources={};outbox={};last_ack=0 end
    ack=type(ack)=="number" and ack>=0 and ack<scene.seq and ack==math.floor(ack) and ack or 0
    local full=not next(previous) or ack==0 and last_ack>0
    if ack>=last_ack then
        last_ack=ack
        while outbox[1] and outbox[1].seq<=ack do table.remove(outbox,1) end
    end
    local entities,upserts,updates,removed={},{},{},{}
    for _,entity in ipairs(scene.entities) do
        local before=previous[entity.id]
        local revision=revisions and revisions[entity.id]
        local stable=before and (revision and revision==before.revision or not revision and Same(entity,before.stable,position))
        local old=before and before.dynamic
        local unchanged=old and old[2]==entity.x and old[3]==entity.y and old[4]==entity.z and old[5]==entity.art.percent and old[6]==entity.art.rotation
        local dynamic=unchanged and old or {entity.id,entity.x,entity.y,entity.z,entity.art.percent,entity.art.rotation}
        entities[entity.id]={stable=stable and before.stable or Freeze(entity,position),dynamic=dynamic,revision=revision}
        if not stable then table.insert(upserts,json.encode(entity))
        -- Native JSON uses tostring for numbers; avoid its recursive table scan for this fixed numeric record.
        elseif not unchanged then table.insert(updates,"["..table.concat(dynamic,",").."]") end
    end
    for id in pairs(previous) do if not entities[id] then table.insert(removed,id) end end
    local current,changed={},{}
    for name,value in pairs(scene) do if name~="entities" and name~="seq" then
        local same=immutable[value] and sources[name]==value or Same(value,metadata[name]);current[name]=same and metadata[name] or Freeze(value)
        sources[name]=value
        if not same then table.insert(changed,json.encode(name)..":"..json.encode(value)) end
    end end
    local delta='{"seq":'..scene.seq..',"set":{'..table.concat(changed,",")..'},"upsert":['..table.concat(upserts,",")..'],"update":['..table.concat(updates,",")..'],"remove":'..json.encode(removed)..'}'
    local bytes=#delta;for _,message in ipairs(outbox) do bytes=bytes+#message.text end
    if full or #outbox>=32 or bytes>8*1024*1024 then
        outbox={{seq=scene.seq,text='{"seq":'..scene.seq..',"full":'..json.encode(scene)..'}'}}
    else table.insert(outbox,{seq=scene.seq,text=delta}) end
    previous,metadata=entities,current
    local messages={};for _,message in ipairs(outbox) do table.insert(messages,message.text) end
    return '{"version":2,"pair":'..json.encode(scene.pair)..',"session":'..json.encode(scene.session)..',"seq":'..scene.seq..',"messages":['..table.concat(messages,",")..']}'
end
return M
