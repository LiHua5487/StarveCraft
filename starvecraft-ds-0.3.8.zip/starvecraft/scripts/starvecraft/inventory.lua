-- MC owns slots/count transfers; native objects keep running in this private container.
local M={entries={},imports={},version=0,holders={},merge_receipts={},location_receipts={},failed_imports={}}
local json=require("json")
local channel=require("starvecraft/channel")
local link=require("starvecraft/link")
local player,vault
local seq,last_mc_seq,last_context=0,-1,""
local offered_merges,offered_locations={},{}
local perishing={}
local Refresh

local function ValidId(id)
    return type(id)=="string" and #id>0 and #id<=128 and id:match("^[%w_:%-]+$")~=nil
end
local function Integer(value,min,max)
    return type(value)=="number" and value>=min and value<=max and value==math.floor(value)
end
local function Array(values,limit)
    if type(values)~="table" or #values>limit then return false end
    local size=0
    for key in pairs(values) do
        if not Integer(key,1,#values) then return false end
        size=size+1
    end
    return size==#values
end
local function Counts(values)
    if not Array(values,4096) then return false end
    local seen={}
    for _,value in ipairs(values) do
        if type(value)~="table" or not ValidId(value.item_id) or seen[value.item_id]
            or not Integer(value.count,0,6400) or not Integer(value.revision,0,9007199254740991)
            or value.received~=nil and type(value.received)~="boolean" then return false end
        seen[value.item_id]=value
    end
    return seen
end
local function Importable(spec)
    if type(spec)~="table" or spec.managed~=nil and spec.managed~=false or spec.request~=nil or spec.preview~=nil
        or type(spec.prefab)~="string" or #spec.prefab>64 or not spec.prefab:match("^[%w_]+$")
        or not Prefabs[spec.prefab] or not Integer(spec.count or 1,1,6400)
        or spec.origin~=nil and spec.origin~="mc" and spec.origin~="ds" then return false end
    if spec.created~=nil and spec.created~=true then return false end
    if spec.created and (spec.record~=nil or spec.structure_recipe~=nil or spec.origin~=nil and spec.origin~="ds") then return false end
    if spec.created_recipe~=nil and (not spec.created or type(spec.created_recipe)~="string" or #spec.created_recipe>64 or not spec.created_recipe:match("^[%w_]+$")) then return false end
    if spec.record~=nil and (type(spec.record)~="table" or spec.record.prefab~=spec.prefab) then return false end
    if spec.structure_recipe~=nil and (type(spec.structure_recipe)~="string" or not spec.structure_recipe:match("^[%w_]+$")) then return false end
    if spec.item_id~=nil and (not ValidId(spec.item_id) or not spec.record and not spec.structure_recipe and spec.origin~="mc" and not spec.created) then return false end
    return (spec.record~=nil or spec.structure_recipe~=nil or spec.origin=="mc" or spec.created==true)
        and ValidId(spec.import_id or spec.item_id and "legacy:"..spec.item_id)
end
local function Count(item)
    return item.components.stackable and item.components.stackable:StackSize() or 1
end
local function Equal(a,b)
    if type(a)~=type(b) then return false end
    if type(a)~="table" then return a==b end
    for k,v in pairs(a) do if not Equal(v,b[k]) then return false end end
    for k in pairs(b) do if a[k]==nil then return false end end
    return true
end
local function Identity(item,id)
    assert(item and item:IsValid() and item.components.inventoryitem,"not a native inventory item")
    id=id or item.sc_item_id or (link.session.."-i-"..item.GUID)
    assert(ValidId(id),"invalid native item identity")
    item.sc_item_id=id
    item.sc_mc_origin=item.sc_mc_origin or "ds"
    return id
end
local function Ownership(item)
    if not item or not item:IsValid() or not item.components.inventoryitem then return "removed",false end
    local owner=item.components.inventoryitem.owner
    if owner==vault and vault and vault.components.container:GetItemSlot(item) then return "vault",true end
    if owner and owner:HasTag("sc_itemholder") and owner.components.container:GetItemSlot(item) then return "holder:"..owner.sc_holder,true end
    if owner==player and player and item.sc_mc_domain then
        local slot=player.components.inventory:IsItemEquipped(item)
        if slot then return "equipped:"..tostring(slot),true end
    end
    return owner and "native" or "ground",false
end
local function View(item)
    local spec=require("starvecraft/items").Describe(item,true)
    spec.record=nil
    spec.item_id=Identity(item)
    spec.managed=true
    spec.origin=item.sc_mc_origin
    local owner=item.components.inventoryitem.owner
    spec.mc_holder=owner and owner.sc_holder or "carried"
    if item.components.stackable then spec.native_stack_max=item.components.stackable.maxsize end
    spec.revision=nil
    return spec
end
local function Inherit(item,old)
    local previous=M.entries[old.id]
    local assigned=item.sc_item_id
    if assigned and assigned~=old.id and M.entries[assigned] and M.entries[assigned].item==item then
        if M.entries[assigned].ever_mc then M.entries[assigned].item=nil else M.entries[assigned]=nil end
    end
    item.sc_item_id=old.id
    item.sc_mc_origin=old.origin
    item.sc_mc_stack=old.mc_stack;item.sc_mc_prefab=old.mc_prefab
    item.sc_mc_condition_total=old.mc_condition_total;item.sc_mc_condition_basis=old.mc_condition_basis;item.sc_mc_condition_last=old.mc_condition_last
    item.sc_mc_condition_seq=old.mc_condition_seq;item.sc_mc_condition_session=old.mc_condition_session
    item.sc_mc_domain=true
    item.sc_mc_seen=true
    if previous then previous.item=item end
    M.Track(item)
end

function M.Track(item)
    local id=Identity(item)
    local previous=item.sc_inventory_tracked_id
    if previous and previous~=id and M.entries[previous] and M.entries[previous].item==item then
        if M.entries[previous].ever_mc then M.entries[previous].item=nil else M.entries[previous]=nil end
    end
    item.sc_inventory_tracked_id=id
    local entry=M.entries[id]
    assert(not entry or not entry.item or entry.item==item or not entry.item:IsValid(),"duplicate native item identity")
    if not entry then
        entry={revision=item.sc_item_revision or 0,ever_mc=item.sc_mc_seen==true}
        M.entries[id]=entry
    end
    entry.item=item
    if not item.sc_inventory_tracked then
        item.sc_inventory_tracked=true
        item:ListenForEvent("onremove",function()
            local current=M.entries[item.sc_item_id]
            if current and current.item==item then
                if current.ever_mc then current.item=nil else M.entries[item.sc_item_id]=nil end
            end
        end)
    end
        local stack=item.components.stackable
        if stack and not stack.sc_inventory_get then
            stack.sc_inventory_get=true
            local get=stack.Get
            function stack:Get(...)
                local part=get(self,...)
                if part and part~=item then
                    part.sc_mc_origin=item.sc_mc_origin;part.sc_mc_stack=item.sc_mc_stack;part.sc_mc_prefab=item.sc_mc_prefab
                    part.sc_mc_condition_total=item.sc_mc_condition_total;part.sc_mc_condition_basis=item.sc_mc_condition_basis;part.sc_mc_condition_last=item.sc_mc_condition_last
                    part.sc_mc_condition_seq=item.sc_mc_condition_seq;part.sc_mc_condition_session=item.sc_mc_condition_session
                    M.Track(part)
                end
                return part
            end
        end
        local perish=item.components.perishable
        if perish and not perish.sc_inventory_perish then
            perish.sc_inventory_perish=true
            local original=perish.Perish
            function perish:Perish(...)
                local holder=item.components.inventoryitem.owner
                local owned=Ownership(item)
                local marker={id=item.sc_item_id,origin=item.sc_mc_origin,holder=holder,replacement=self.onperishreplacement,
                    mc_stack=item.sc_mc_stack,mc_prefab=item.sc_mc_prefab,
                    mc_condition_total=item.sc_mc_condition_total,mc_condition_basis=item.sc_mc_condition_basis,mc_condition_last=item.sc_mc_condition_last,
                    mc_condition_seq=item.sc_mc_condition_seq,mc_condition_session=item.sc_mc_condition_session,
                    slot=holder and holder.components.container and holder.components.container:GetItemSlot(item)}
                local eligible=item.sc_mc_seen and (holder==vault or owned:match("^equipped:") or owned:match("^holder:"))
                if eligible then table.insert(perishing,marker) end
                local ok,result=pcall(original,self,...)
                if eligible then table.remove(perishing) end
                if not ok then error(result) end
                return result
            end
        end
    return item
end
function M.Id(item) M.Track(item);return item.sc_item_id end

Refresh=function(id)
    local entry=M.entries[id]
    if not entry then return end
    local item=entry.item
    local owner,owned=Ownership(item)
    local spec=owned and View(item) or {item_id=id,managed=true,removed=true,count=0}
    if not owned or not entry.mc then entry.confirmed=false end
    if owned then entry.ever_mc=true;item.sc_mc_seen=true end
    if not Equal(spec,entry.spec) or owner~=entry.owner then
        entry.revision=entry.revision+1
        if not entry.spec or entry.spec.count~=spec.count or entry.spec.prefab~=spec.prefab or owner~=entry.owner then entry.count_revision=entry.revision end
        M.version=M.version+1
        entry.spec=spec;entry.owner=owner
    end
    entry.mc=owned
    if item and item:IsValid() then item.sc_item_revision=entry.revision end
    return entry
end
function M.Revision(id)
    local entry=Refresh(id)
    return entry and entry.revision or 0
end
function M.Describe(item)
    local id=M.Id(item)
    local entry=Refresh(id)
    local spec=View(item)
    spec.revision=entry.revision
    return spec
end
function M.Find(spec)
    local id=type(spec)=="table" and spec.item_id or spec
    local entry=M.entries[id]
    local item=entry and entry.item
    if item and item:IsValid() then
        local _,owned=Ownership(item)
        if owned then return item end
    end
end
function M.Detach(item)
    local inv=item.components.inventoryitem
    if inv.owner then inv:RemoveFromOwner(true) end
    -- Stackable:Get temporarily inherits its parent's owner without entering a slot.
    if inv.owner then inv:OnRemoved() end
    local entry=M.entries[item.sc_item_id]
    if entry then entry.confirmed=false end
    return item
end
function M.Keep(item)
    assert(vault and vault:IsValid(),"native item vault not ready")
    local marker=perishing[#perishing]
    if marker and item.prefab==marker.replacement and item.sc_item_id~=marker.id then Inherit(item,marker) end
    M.Track(item)
    if item.components.inventoryitem.owner~=vault then
        Refresh(item.sc_item_id)
        M.Detach(item)
        local container=vault.components.container
        local slot=1
        while container.slots[slot] do slot=slot+1 end
        if slot>container.numslots then container:SetNumSlots(math.max(slot,container.numslots*2)) end
        item.sc_mc_domain=true;item.persists=true
        assert(container:GiveItem(item,slot,nil,false,true),"cannot retain native inventory item")
    end
    item.sc_mc_domain=true;item.persists=true;item.sc_mc_seen=true
    return M.Describe(item)
end
function M.Take(spec,count)
    local item=M.Find(spec)
    if not item then return end
    count=count or (type(spec)=="table" and spec.count) or Count(item)
    if type(count)~="number" or count~=math.floor(count) or count<1 or count>Count(item) then return end
    if count<Count(item) then
        local part=item.components.stackable:Get(count)
        M.Detach(part)
        part.sc_mc_origin=item.sc_mc_origin;part.sc_mc_domain=true;part.persists=true
        M.Track(part);Refresh(item.sc_item_id)
        return part
    end
    M.Detach(item);item.sc_mc_domain=true;item.persists=true
    return item
end
function M.Import(spec)
    if type(spec)~="table" then return end
    if spec.managed then return M.Find(spec) end
    if not Importable(spec) then return end
    local key=spec.import_id
    if spec.item_id then
        key="legacy:"..spec.item_id
        if M.entries[spec.item_id] then return M.Find(spec.item_id) end
    end
    if not ValidId(key) then return end
    if M.imports[key] then return M.Find(M.imports[key]) end
    local count=tonumber(spec.count) or 1
    if count~=math.floor(count) or count<1 or count>6400 then return end
    local failed=M.failed_imports[key]
    if failed and failed.prefab==spec.prefab and failed.count==count then return end
    local record=spec.record and deepcopy(spec.record)
    if record and record.prefab~=spec.prefab then return end
    if record then record.x,record.y,record.z=0,0,0 end
    local item
    if spec.structure_recipe then item=SpawnPrefab("blueprint");require("starvecraft/items").Parcel(item,spec)
    else item=record and SpawnSaveRecord(record) or SpawnPrefab(spec.prefab) end
    assert(item and item.components.inventoryitem,"import is not an inventory item")
    if spec.item_id then item.sc_item_id=spec.item_id end
    item.sc_mc_origin=spec.created and "ds" or spec.origin or ((record or spec.structure_recipe) and "ds" or "mc")
    item.sc_mc_stack=spec.mc_stack;item.sc_mc_prefab=spec.mc_stack and spec.prefab or nil
    require("starvecraft/equipment").SyncCondition(item,spec,true)
    if item.components.stackable then item.components.stackable:SetStackSize(count)
    elseif count~=1 then
        item:Remove();M.failed_imports[key]={prefab=spec.prefab,count=count}
        print("[StarveCraft] MC stack cannot enter a non-stackable native item: "..spec.prefab.." x"..count)
        return
    end
    M.failed_imports[key]=nil
    M.Track(item)
    M.imports[key]=item.sc_item_id
    M.Keep(item)
    if spec.created then M.entries[item.sc_item_id].confirmed=true end
    -- shortcut: callbacks run once per materialized object; use craft events if per-craft statistics are needed.
    if spec.created and spec.created_recipe then
        local recipe=GetRecipe(spec.created_recipe)
        local owner=GetPlayer()
        local builder=owner and owner.components.builder
        if recipe and recipe.product==item.prefab and not recipe.placer and builder then
            owner:PushEvent("builditem",{item=item,recipe=recipe})
            if builder.onBuild then builder.onBuild(owner,item) end
            item:OnBuilt(owner)
            if not builder:KnowsRecipe(recipe.name) then builder:UnlockRecipe(recipe.name) end
        end
    end
    return item
end

function M.HookItem(component)
    local item=component.inst
    Identity(item)
    local save,load=component.OnSave,component.OnLoad
    function component:OnSave(...)
        local data,refs
        if save then data,refs=save(self,...) end
        data=data or {}
        data.starvecraft={id=item.sc_item_id,origin=item.sc_mc_origin,mc=item.sc_mc_domain==true,
            seen=item.sc_mc_seen==true,revision=item.sc_item_revision or 0,mc_stack=item.sc_mc_stack,mc_prefab=item.sc_mc_prefab,
            mc_condition_total=item.sc_mc_condition_total,mc_condition_basis=item.sc_mc_condition_basis,mc_condition_last=item.sc_mc_condition_last,
            mc_condition_seq=item.sc_mc_condition_seq,mc_condition_session=item.sc_mc_condition_session}
        return data,refs
    end
    function component:OnLoad(data,...)
        if load then load(self,data,...) end
        local state=data and data.starvecraft
        if state and ValidId(state.id) then
            item.sc_item_id=state.id;item.sc_mc_origin=state.origin or "ds"
            item.sc_mc_stack=state.mc_stack;item.sc_mc_prefab=state.mc_prefab
            item.sc_mc_condition_total=state.mc_condition_total;item.sc_mc_condition_basis=state.mc_condition_basis;item.sc_mc_condition_last=state.mc_condition_last
            item.sc_mc_condition_seq=state.mc_condition_seq;item.sc_mc_condition_session=state.mc_condition_session
            item.sc_mc_domain=state.mc==true;item.sc_mc_seen=state.seen==true
            item.sc_item_revision=tonumber(state.revision) or 0
            if item.sc_mc_seen or item.sc_mc_domain then M.Track(item) end
        end
    end
end
function M.BindVault(inst)
    assert(not vault or vault==inst or not vault:IsValid(),"duplicate native item vault")
    vault=inst
    inst:ListenForEvent("itemget",function(_,data)
        local item=data.item
        local marker=perishing[#perishing]
        if marker and marker.holder==inst and marker.slot==data.slot and item.prefab==marker.replacement then Inherit(item,marker) end
        item.sc_mc_domain=true;item.sc_mc_seen=true;item.persists=true
        M.Track(item)
    end)
end
function M.SaveVault(data)
    local states={}
    for id,entry in pairs(M.entries) do
        Refresh(id)
        if entry.ever_mc then states[id]={revision=entry.revision,spec=entry.spec,owner=entry.owner,
            ever_mc=true,mc=entry.mc,confirmed=entry.confirmed==true,count_revision=entry.count_revision} end
    end
    data.sc_inventory={version=M.version,entries=states,imports=M.imports,merge_receipts=M.merge_receipts,location_receipts=M.location_receipts,failed_imports=M.failed_imports}
end
function M.LoadVault(data)
    local state=data and data.sc_inventory
    if not state then return end
    M.version=state.version or 0;M.imports=state.imports or {}
    M.merge_receipts=state.merge_receipts or {};M.location_receipts=state.location_receipts or {}
    M.failed_imports=state.failed_imports or {}
    for id,saved in pairs(state.entries or {}) do
        local entry=M.entries[id] or {}
        entry.revision=math.max(entry.revision or 0,saved.revision or 0)
        entry.spec=saved.spec;entry.owner=saved.owner;entry.ever_mc=true
        entry.mc=saved.mc==true;entry.confirmed=saved.confirmed==true
        entry.count_revision=saved.count_revision or entry.revision
        M.entries[id]=entry
    end
end
function M.Snapshot()
    local list={}
    for id in pairs(M.entries) do
        local entry=Refresh(id)
        if entry.ever_mc then
            local spec=deepcopy(entry.spec)
            spec.id=id;spec.item_id=id;spec.revision=entry.revision
            table.insert(list,spec)
        end
    end
    table.sort(list,function(a,b) return a.item_id<b.item_id end)
    return list
end
function M.Export()
    seq=seq+1
    local merges,bindings,placed={},{},{}
    for _,id in ipairs(offered_merges) do if M.merge_receipts[id] then table.insert(merges,M.merge_receipts[id]) end end
    for _,id in ipairs(offered_locations) do
        local receipt=M.location_receipts[id]
        if receipt then
            table.insert(placed,id)
            for _,binding in ipairs(receipt) do table.insert(bindings,binding) end
        end
    end
    local state={version=1,pair=link.PairId(),session=link.session,seq=seq,items=M.Snapshot(),merge_results=merges,bindings=bindings,placed=placed}
    channel.Write("ds_inventory.json","seq "..seq.."\n"..json.encode(state).."\nend "..seq.."\n")
end
function M.Sync(counts,pending)
    if pending or not Counts(counts) then return false end
    for _,count in ipairs(counts) do
        local entry=Refresh(count.item_id)
        if entry and entry.mc and count.revision>=(entry.count_revision or entry.revision) then
            if count.count>0 or count.received==true then entry.confirmed=true end
            local item=entry.item
            local difference=Count(item)-count.count
            if difference>0 and entry.confirmed then
                if count.count==0 then item:Remove()
                elseif item.components.stackable then item.components.stackable:Get(difference):Remove() end
                Refresh(count.item_id)
            end
        end
    end
    return true
end
function M.BindHolder(inst,key)
    inst.sc_holder=key
    if key then M.holders[key]=inst end
    if inst.sc_bound then return end
    inst.sc_bound=true
    inst:ListenForEvent("itemget",function(_,data)
        local item=data.item;local marker=perishing[#perishing]
        if marker and marker.holder==inst and marker.slot==data.slot and item.prefab==marker.replacement then Inherit(item,marker) end
        item.sc_mc_domain=true;item.sc_mc_seen=true;item.persists=true;M.Track(item)
    end)
    inst:ListenForEvent("onremove",function() if M.holders[inst.sc_holder]==inst then M.holders[inst.sc_holder]=nil end end)
end
local function KeepAt(item,location)
    if location.carried then
        local _,owned=Ownership(item)
        if item.components.inventoryitem.owner==player and owned then return M.Describe(item) end
        return M.Keep(item)
    end
    local holder=M.holders[location.holder]
    if not holder or not holder:IsValid() then holder=SpawnPrefab("sc_itemholder");M.BindHolder(holder,location.holder) end
    local x,_,z=require("starvecraft/mcbridge").ToDS(location.x,0,location.z)
    holder.Transform:SetPosition(x,0,z)
    if item.components.inventoryitem.owner~=holder then
        M.Detach(item);local container=holder.components.container;local slot=1
        while container.slots[slot] do slot=slot+1 end
        if slot>container.numslots then container:SetNumSlots(math.max(slot,container.numslots*2)) end
        item.sc_mc_domain=true;item.persists=true
        assert(container:GiveItem(item,slot,nil,false,true),"cannot retain native item at MC container")
    end
    return M.Describe(item)
end
local function MergeRequest(request)
    if type(request)~="table" or not ValidId(request.id) or not ValidId(request.target)
        or not Integer(request.target_count,1,6400) or not Integer(request.limit,1,99) or not Array(request.sources,128) or #request.sources==0 then return false end
    local total=0
    for _,source in ipairs(request.sources) do
        if type(source)~="table" or not ValidId(source.item_id) or source.item_id==request.target or not Integer(source.count,1,6400) then return false end
        if source.item~=nil and (type(source.item)~="table" or source.item.item_id~=source.item_id or #json.encode(source.item)>65536
            or not source.item.managed and not Importable(source.item)) then return false end
        total=total+source.count
    end
    if request.target_item~=nil and (type(request.target_item)~="table" or request.target_item.item_id~=request.target
        or #json.encode(request.target_item)>65536 or not request.target_item.managed and not Importable(request.target_item)) then return false end
    return total<=6400
end
local function LocationRequest(request)
    if type(request)~="table" or not ValidId(request.id) or not ValidId(request.item_id) or not Integer(request.revision,0,9007199254740991)
        or not Array(request.holders,256) or #request.holders==0 then return false end
    local total,seen=0,{}
    for _,holder in ipairs(request.holders) do
        if type(holder)~="table" or type(holder.holder)~="string" or #holder.holder>512 or not holder.holder:match("^[%w_:%-%.%/]+$")
            or seen[holder.holder] or not ValidId(holder.token) or type(holder.carried)~="boolean" or not Integer(holder.count,1,6400)
            or type(holder.x)~="number" or holder.x~=holder.x or math.abs(holder.x)>1000000
            or type(holder.z)~="number" or holder.z~=holder.z or math.abs(holder.z)>1000000 then return false end
        seen[holder.holder]=true;total=total+holder.count
    end
    return total<=6400
end
function M.Merge(request)
    if not MergeRequest(request) then return end
    if M.merge_receipts[request.id] then return M.merge_receipts[request.id] end
    local result={id=request.id,moved=0,refunds={}}
    local original=M.Find(request.target) or request.target_item and M.Import(request.target_item)
    if original and original.sc_mc_origin=="mc" and request.target_item and request.target_item.mc_stack then original.sc_mc_stack=deepcopy(request.target_item.mc_stack);original.sc_mc_prefab=original.prefab end
    local target=original and Count(original)>=request.target_count and M.Take(request.target,request.target_count)
    for _,source in ipairs(request.sources) do
        local item=M.Find(source.item_id) or source.item and M.Import(source.item)
        if item and item.sc_mc_origin=="mc" and source.item and source.item.mc_stack then item.sc_mc_stack=deepcopy(source.item.mc_stack);item.sc_mc_prefab=item.prefab end
        local part=item and M.Take(source.item_id,math.min(source.count,Count(item)))
        if part then
            if target and target.components.stackable and part.components.stackable and target.prefab==part.prefab
                and target.sc_mc_origin==part.sc_mc_origin and Equal(target.sc_mc_stack,part.sc_mc_stack)
                and Count(target)<request.limit then
                local before=Count(target)
                -- MC owns this slot's capacity; Put still owns native mixing and object destruction.
                local stack=target.components.stackable;local maximum=stack.maxsize
                stack.maxsize=request.limit
                local ok,err=pcall(stack.Put,stack,part)
                stack.maxsize=maximum
                if not ok then error(err) end
                result.moved=result.moved+Count(target)-before
            end
            if part:IsValid() then
                local spec=M.Keep(part);M.entries[spec.item_id].confirmed=true;spec.return_to=source.address;table.insert(result.refunds,spec)
            end
        end
    end
    if target then result.target=M.Keep(target);M.entries[result.target.item_id].confirmed=true end
    M.merge_receipts[request.id]=result
    return result
end
function M.Place(request)
    if not LocationRequest(request) then return end
    if M.location_receipts[request.id] then return M.location_receipts[request.id] end
    local result={};local item=M.Find(request.item_id);local total=0
    for _,holder in ipairs(request.holders) do total=total+holder.count end
    local entry=item and Refresh(request.item_id)
    if item and total<=Count(item) and request.revision>=(entry.count_revision or entry.revision) then
        if total<Count(item) then item.components.stackable:Get(Count(item)-total):Remove() end
        for index=#request.holders,1,-1 do
            local holder=request.holders[index]
            local part=M.Take(request.item_id,holder.count)
            if part then
                local spec=KeepAt(part,holder);M.entries[spec.item_id].confirmed=true
                table.insert(result,{id=holder.token,item=spec})
            end
        end
    end
    M.location_receipts[request.id]=result
    return result
end
function M.Receive(text)
    if type(text)~="string" or #text>2097152 then return false end
    local first,body,last=text:match("^seq (%d+)\n(.*)\nend (%d+)%s*$")
    if first~=last or not first then return false end
    local ok,state=pcall(json.decode,body)
    local context=link.PairId()..":"..link.McSession()..":"..link.session
    if context~=last_context then last_context=context;last_mc_seq=-1 end
    if not ok or type(state)~="table" or state.version~=1 or not Integer(state.seq,0,9007199254740991)
        or state.seq~=tonumber(first) or state.seq<=last_mc_seq or state.pair~=link.PairId()
        or (state.session or state.mc_session)~=link.McSession() or state.session and state.mc_session and state.session~=state.mc_session
        or state.mc_session~=nil and type(state.mc_session)~="string"
        or state.ds_session~=link.session or type(state.pending)~="boolean" then return false end
    local counts=Counts(state.counts)
    local legacy=state.legacy or {}
    if not counts or not Array(legacy,4096) then return false end
    local merges,locations=state.merge_requests or {},state.location_requests or {}
    if not Array(merges,128) or not Array(locations,4096) then return false end
    local operations={}
    for _,request in ipairs(merges) do if not MergeRequest(request) or operations[request.id] then return false end;operations[request.id]=true end
    for _,request in ipairs(locations) do if not LocationRequest(request) or operations[request.id] then return false end;operations[request.id]=true end
    local seen={}
    for _,spec in ipairs(legacy) do
        if type(spec)~="table" or not ValidId(spec.item_id) or seen[spec.item_id]
            or not counts[spec.item_id] or spec.count~=counts[spec.item_id].count
            or #json.encode(spec)>65536 then return false end
        seen[spec.item_id]=true
        local pending=spec.request~=nil or spec.preview~=nil
        if pending and not state.pending or not pending and not Importable(spec) then return false end
    end
    if not state.pending then
        for _,spec in ipairs(legacy) do if spec.request==nil and spec.preview==nil then M.Import(spec) end end
        M.Sync(state.counts,false)
    end
    offered_merges,offered_locations={},{}
    for _,request in ipairs(merges) do M.Merge(request);table.insert(offered_merges,request.id) end
    for _,request in ipairs(locations) do M.Place(request);table.insert(offered_locations,request.id) end
    last_mc_seq=state.seq
    return true
end
function M.Install(inst)
    player=inst
    if not vault then vault=SpawnPrefab("sc_itemvault") end
    assert(vault and vault:IsValid(),"cannot create native item vault")
    local x,y,z=player.Transform:GetWorldPosition()
    vault.Transform:SetPosition(x,y,z)
    for _,item in pairs(vault.components.container.slots) do M.Track(item) end
    player:DoPeriodicTask(.25,function()
        if link.Active() then
            local px,py,pz=player.Transform:GetWorldPosition()
            vault.Transform:SetPosition(px,py,pz)
            M.Receive(channel.Read("mc_inventory.json"));M.Export()
            for key,holder in pairs(M.holders) do if not next(holder.components.container.slots) then holder:Remove();M.holders[key]=nil end end
        end
    end)
end
return M
