-- The original MapScreen/MiniMap render everything; MC forwards UI input and displays its pixels.
local M={}
local json=require("json")
local channel=require("starvecraft/channel")
local screen,token,last_zoom,last_x,last_y,last_click,last_rotate,close_requested
function M.Update(active,pose)
    local requested=active and pose and pose.map_open and type(pose.map_token)=="string" and pose.map_token:match("^[%w%-]+$")
    if not requested or token~=pose.map_token then
        if screen then
            TheFrontEnd:PopScreen(screen)
            SetPause(not active or (pose and pose.paused) or false,"starvecraft")
        end
        screen,token=nil,nil
    end
    if not requested then return end
    if not screen then
        screen=require("screens/mapscreen")()
        token=pose.map_token
        last_zoom,last_x,last_y,last_click,last_rotate=0,0,0,0,0
        close_requested=false
        TheFrontEnd:PushScreen(screen)
    end
    if TheFrontEnd:GetActiveScreen()~=screen then
        channel.Write("native_map_state.json",json.encode({map_token=token,ready=false,close=true,buttons={}}).."\n")
        return
    end
    local input=pose.map_input or {}
    local zoom=tonumber(input.zoom) or 0
    local delta=math.max(-8,math.min(8,zoom-last_zoom))
    for i=1,math.abs(delta) do
        if delta>0 then screen.minimap:OnZoomIn() else screen.minimap:OnZoomOut() end
    end
    last_zoom=zoom
    local x,y=tonumber(input.x) or 0,tonumber(input.y) or 0
    if math.abs(x-last_x)<10000 and math.abs(y-last_y)<10000 then screen.minimap:Offset(x-last_x,y-last_y) end
    last_x,last_y=x,y
    local rotate=tonumber(input.rotate) or 0
    if rotate~=last_rotate then
        screen:OnControl(rotate>last_rotate and CONTROL_ROTATE_RIGHT or CONTROL_ROTATE_LEFT,true)
        last_rotate=rotate
    end
    local buttons={}
    local sw,sh=TheSim:GetScreenSize()
    local controls=screen.mapcontrols
    if controls then
        for key,button in pairs({left=controls.rotleft,right=controls.rotright,close=controls.minimapBtn}) do
            local p=button:GetWorldPosition()
            local w,h=button:GetSize()
            local sx,sy=1,1
            local parent=button
            while parent do local s=parent:GetScale();sx,sy=sx*s.x,sy*s.y;parent=parent.parent end
            table.insert(buttons,{key=key,x=p.x/sw,y=1-p.y/sh,w=math.abs(w*sx)/sw,h=math.abs(h*sy)/sh})
        end
        if input.click and input.click~=last_click then
            if input.button=="left" then controls.rotleft.onclick()
            elseif input.button=="right" then controls.rotright.onclick()
            elseif input.button=="close" then close_requested=true end
            last_click=input.click
        end
    end
    channel.Write("native_map_state.json",json.encode({map_token=token,ready=true,close=close_requested,
        width=sw,height=sh,buttons=buttons}).."\n")
end
return M
