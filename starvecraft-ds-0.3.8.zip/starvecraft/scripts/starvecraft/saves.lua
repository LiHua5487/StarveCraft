-- Runtime and test saves have different namespaces; neither touches vanilla saves.
require("saveindex")
require("playerprofile")
require("playerdeaths")
local M = {}
function M.Install(prefix)
    for _, entry in ipairs({{SaveIndex,"GetSaveIndexName"}, {SaveIndex,"GetSaveGameName"},
        {PlayerProfile,"GetSaveName"}, {PlayerDeaths,"GetSaveName"}}) do
        local cls, name = entry[1], entry[2]
        local old = cls[name]
        cls[name] = function(...) return prefix .. old(...) end
    end
end
return M
