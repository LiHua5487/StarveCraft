-- Unit and item mappings only; gameplay remains in the two native engines.
local M = { DAMAGE_SCALE = 6 }
local LOOT_TO_MC = {
    axe = "minecraft:stone_axe",
    pickaxe = "minecraft:stone_pickaxe",
    shovel = "minecraft:stone_shovel",
    hammer = "minecraft:stone_pickaxe",
    spear = "minecraft:stone_sword",
    torch = "minecraft:torch",
    fishingrod = "minecraft:fishing_rod",
    log = "minecraft:oak_log",
    charcoal = "minecraft:charcoal",
    pinecone = "minecraft:spruce_sapling",
    acorn = "minecraft:birch_sapling",
    twigs = "minecraft:stick",
    cutgrass = "minecraft:short_grass",
    rocks = "minecraft:cobblestone",
    flint = "minecraft:flint",
    goldnugget = "minecraft:gold_nugget",
    berries = "minecraft:sweet_berries",
    carrot = "minecraft:carrot",
    seeds = "minecraft:wheat_seeds",
    meat = "minecraft:beef",
    cookedmeat = "minecraft:cooked_beef",
    smallmeat = "minecraft:rabbit",
    cookedsmallmeat = "minecraft:cooked_rabbit",
    drumstick = "minecraft:chicken",
    monstermeat = "minecraft:rotten_flesh",
    pigskin = "minecraft:leather",
    beefalowool = "minecraft:white_wool",
    silk = "minecraft:string",
    spidergland = "minecraft:spider_eye",
    houndstooth = "minecraft:bone",
    feather_crow = "minecraft:feather",
    feather_robin = "minecraft:feather",
    feather_robin_winter = "minecraft:feather",
    honey = "minecraft:honey_bottle",
    petals = "minecraft:poppy",
    petals_evil = "minecraft:wither_rose",
    cutreeds = "minecraft:sugar_cane",
    foliage = "minecraft:fern",
    lightbulb = "minecraft:glow_berries",
    red_cap = "minecraft:red_mushroom",
    green_cap = "minecraft:brown_mushroom",
    blue_cap = "minecraft:brown_mushroom",
}

-- 按掉落来源细分：{ 来源 prefab 的 Lua 模式, 饥荒掉落, MC 物品 }
local SOURCE_OVERRIDES = {
    { "^evergreen", "log", "minecraft:spruce_log" },
    { "^deciduoustree", "log", "minecraft:birch_log" },
    { "^pigman", "meat", "minecraft:porkchop" },
    { "^pigguard", "meat", "minecraft:porkchop" },
}


M.LOOT_TO_MC = LOOT_TO_MC
M.CONVERSION_REVERSE = { ["minecraft:stone_pickaxe"]="pickaxe",["minecraft:feather"]="feather_crow",["minecraft:brown_mushroom"]="green_cap" }
M.SOURCE_OVERRIDES = SOURCE_OVERRIDES
function M.ToMC(damage) return damage / M.DAMAGE_SCALE end
function M.ToDS(damage) return damage * M.DAMAGE_SCALE end
function M.HungerToMC(amount, maximum) return amount / maximum * 20 end
function M.HungerToDS(amount, maximum) return amount / 20 * maximum end
return M
