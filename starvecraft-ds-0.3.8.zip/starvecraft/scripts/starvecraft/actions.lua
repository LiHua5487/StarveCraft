-- Native action offers map to MC's target/item stages; no entity-type dispatch.
local M={}
local function first(actions,target)
    local work=target and target.components.workable
    for _,action in ipairs(actions or {}) do
        local kind=action.action
        if kind~=ACTIONS.LOOKAT and kind~=ACTIONS.WALKTO and kind~=ACTIONS.ATTACK
            and kind~=ACTIONS.DROP and kind~=ACTIONS.EQUIP and kind~=ACTIONS.UNEQUIP
            and (not work or kind~=work.action) then return action end
    end
end
function M.Scene(target)
    return first(GetPlayer().components.playeractionpicker:GetSceneActions(target,false),target)
end
function M.Item(target,item)
    local picker=GetPlayer().components.playeractionpicker
    return first(picker:GetUseItemActions(target,item,true),target)
        or first(picker:GetUseItemActions(target,item,false),target)
        or first(picker:GetEquippedItemActions(target,item,true),target)
end
function M.Offers(target)
    local offers,seen={},{}
    local pose=require("starvecraft/mcbridge").pose
    local store=require("starvecraft/inventory")
    for _,spec in ipairs(pose and pose.hands or {}) do
        local item=store.Find(spec)
        if item and not seen[spec.item_id] and M.Item(target,item) then
            seen[spec.item_id]=true;table.insert(offers,spec.item_id)
        end
    end
    return offers
end
local previews=setmetatable({}, {__mode="k"})
function M.Preview(target,nearby)
    local cached=previews[target]
    if not cached or nearby then
        cached={scene=M.Scene(target)~=nil,offers=M.Offers(target),name=target:GetDisplayName()};previews[target]=cached
    end
    return cached
end
return M
