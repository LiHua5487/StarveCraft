-- 饥荒世界 <-> 真 MC 的互通（与 mcmod 的 DsWorldSync 配对）
--   导出：玩家附近的树、石头、生物 -> devio/ds_entities.txt（每 0.1 秒），MC 据此生成碰撞、受击、遮挡替身
--         快照里还带一行 "clock 刻数"：饥荒的昼夜换算成 MC 一天中的时刻，MC 的天色跟着变
--   执行：MC 玩家打替身 / 右键替身 -> devio/mc_events.txt -> 这里对饥荒实体执行 砍 / 挖 / 攻击 / 采摘
--   回传：原生拾取入包、建造/落地确认、聊天与原生受击结果 -> devio/ds_events.txt
-- 事件文件格式见 mcmod 的 DevioEvents：首行会话号，之后每行 "序号 内容 ;"。

local mcbridge = require("starvecraft/mcbridge")
local link = require("starvecraft/link")
local json = require("json")
local animtrack = require("starvecraft/animtrack")
local items = require("starvecraft/items")
local crafting = require("starvecraft/crafting")
local stream=require("starvecraft/scenestream")
local Set=stream.Set

local M = {}
local active_contacts, queued_contacts={},{}
local FinishContact

local DEVIO = STARVECRAFT.MODROOT .. "devio/"
local function ExportRadius()
    return mcbridge.pose and mcbridge.pose.view_distance or 32
end

local light_states=setmetatable({}, {__mode="k"})
local light_sources={}
-- Light has no Lua state to serialize; observe its original setters before prefabs run.
function M.InstallLights()
    if M.lights_installed then return end
    local probe=CreateEntity()
    probe.entity:AddTransform()
    local light=probe.entity:AddLight()
    local api=getmetatable(light).__index
    local entity_api=getmetatable(probe.entity).__index
    assert(type(api)=="table" and type(entity_api)=="table","native Light method table unavailable")
    local function Wrap(name,record)
        local original=api[name]
        assert(type(original)=="function","native Light method unavailable: "..name)
        api[name]=function(self,...)
            local result=original(self,...)
            local state=light_states[self] or {};light_states[self]=state
            record(state,...)
            return result
        end
    end
    Wrap("SetRadius",function(s,n) s.radius=n end)
    Wrap("SetIntensity",function(s,n) s.intensity=n end)
    Wrap("SetFalloff",function(s,n) s.falloff=n end)
    Wrap("SetColour",function(s,r,g,b) s.colour={r,g,b} end)
    local add=entity_api.AddLight
    entity_api.AddLight=function(self,...)
        local result=add(self,...)
        local inst=Ents[self:GetGUID()]
        if inst then light_sources[inst.GUID]=inst end
        return result
    end
    probe:Remove()
    for id,inst in pairs(Ents) do if inst.Light then light_sources[id]=inst end end
    M.lights_installed=true
end

function M.LightSnapshot(px,pz)
    local result={}
    local exposure=require("starvecraft/invasion").exposure
    for id,inst in pairs(light_sources) do
        if not inst:IsValid() or not inst.Light then light_sources[id]=nil
        elseif inst~=exposure and not inst.sc_mc_light and not inst:HasTag("mc_block") and inst.Transform then
            -- Hidden player projections and native follower FX can still have real enabled lights.
            local light=inst.Light
            local state=light_states[light] or {}
            local range=light:GetCalculatedRadius()
            local x,y,z=inst.Transform:GetWorldPosition()
            if type(range)=="number" and range==range and range>=0 and range<=1024
                and (x-px)^2+(z-pz)^2<=(ExportRadius()+range)^2 then
                local mx,my,mz=mcbridge.ToMC(x,y,z)
                table.insert(result,{id=id,x=mx,y=my,z=mz,enabled=light:IsEnabled(),
                    radius=state.radius or range,range=range,intensity=state.intensity or 1,
                    falloff=state.falloff or .5,colour=state.colour or {1,1,1}})
            end
        end
    end
    table.sort(result,function(a,b) return a.id<b.id end)
    assert(#result<=1024,"too many native lights in scene")
    return result
end
-- MC 伤害 x6 ≈ 饥荒伤害（铁剑 6 -> 36，饥荒长矛 34）；饥荒伤害 /6 ≈ MC 伤害（蜘蛛 20 -> 3.3）


-- ------------------------------------------------------------ 饥荒精灵的大致轮廓（MC 侧遮挡用）
-- 轮廓：1 针叶树（树干 + 三角树冠）、2 椭圆、3 圆冠树（树干 + 椭圆树冠）；宽、高单位为饥荒单位（= MC 方块）

local SHAPE_CONIFER, SHAPE_ELLIPSE, SHAPE_ROUND_TREE = 1, 2, 3

local function TreeStage(inst)
    return inst.components.growable and inst.components.growable.stage or 2
end

local function Staged(shape, sizes)
    return function(inst)
        if inst:HasTag("stump") then
            return SHAPE_ELLIPSE, .9, .6
        end
        local s = sizes[TreeStage(inst)] or sizes[2]
        return shape, s[1], s[2]
    end
end

local function Fixed(shape, w, h)
    return function()
        return shape, w, h
    end
end

local PROFILES = {
    evergreen = Staged(SHAPE_CONIFER, { { 1.6, 2.6 }, { 2.4, 4.0 }, { 3.0, 5.4 }, { 1.4, 2.6 } }),
    evergreen_sparse = Staged(SHAPE_CONIFER, { { 1.4, 2.4 }, { 2.0, 3.6 }, { 2.6, 5.0 }, { 1.4, 2.6 } }),
    deciduoustree = Staged(SHAPE_ROUND_TREE, { { 1.6, 2.4 }, { 2.6, 3.8 }, { 3.2, 5.0 }, { 1.4, 2.6 } }),
    rock1 = Fixed(SHAPE_ELLIPSE, 2.2, 1.6),
    rock2 = Fixed(SHAPE_ELLIPSE, 2.2, 1.6),
    rock_flintless = Fixed(SHAPE_ELLIPSE, 2.0, 1.4),
    berrybush = Fixed(SHAPE_ELLIPSE, 1.6, 1.4),
    berrybush2 = Fixed(SHAPE_ELLIPSE, 1.6, 1.4),
    grass = Fixed(SHAPE_ELLIPSE, .9, 1.1),
    sapling = Fixed(SHAPE_ELLIPSE, .8, 1.1),
    flower = Fixed(SHAPE_ELLIPSE, .7, .6),
    pigman = Fixed(SHAPE_ELLIPSE, 1.2, 2.4),
    beefalo = Fixed(SHAPE_ELLIPSE, 2.6, 2.6),
    spider = Fixed(SHAPE_ELLIPSE, 1.4, .9),
    spider_warrior = Fixed(SHAPE_ELLIPSE, 1.5, 1.1),
    hound = Fixed(SHAPE_ELLIPSE, 1.6, 1.4),
    rabbit = Fixed(SHAPE_ELLIPSE, .6, .6),
    frog = Fixed(SHAPE_ELLIPSE, .7, .6),
}

local function Profile(inst, radius)
    local fn = PROFILES[inst.prefab]
    if fn then
        return fn(inst)
    end
    return SHAPE_ELLIPSE, math.max(.6, radius * 2.4), 1.4
end

-- ------------------------------------------------------------ 昼夜 -> MC 时刻
-- 白天 = MC 天快亮到日落前（23500 -> 11500，跨过 0 点），黄昏 = 日落（11500 -> 13500），夜晚 = 13500 -> 22500；
-- 饥荒天亮是一下子亮的，MC 这边也跳过夜里最后的那段黎明

local CLOCK_SPANS = { day = { 23500, 12000 }, dusk = { 11500, 2000 }, night = { 13500, 9000 } }

local function McTime()
    local clock = GetClock()
    local span = clock and CLOCK_SPANS[clock:GetPhase()]
    if span then
        return math.floor(span[1] + span[2] * clock:GetNormEraTime()) % 24000
    end
end

-- ------------------------------------------------------------ 事件文件

local channel = require("starvecraft/channel")
local compat = require("starvecraft/compat")
local WriteFile, Send, PollEvents = channel.Write, channel.Send, channel.Poll

-- ------------------------------------------------------------ 导出实体快照

local WORK_CODES = {}

local function WorkCode(inst)
    local w = inst.components.workable
    if w and w:CanBeWorked() then
        return WORK_CODES[w.action]
    end
end

-- 需要导出的实体返回 { work = 工作代码或 nil, attack = 能否攻击, solid = 是否障碍物, pick = 现在能否采 }，其余返回 nil
local classifications=setmetatable({}, {__mode="k"})
local function Classify(inst, player, nearby)
    if inst == player or not inst.prefab or not inst:IsValid() or inst:IsInLimbo() or not inst.AnimState
        or not inst.entity:IsVisible() or inst:HasTag("player") then
        return nil
    end
    local item = inst.components.inventoryitem and not inst.components.inventoryitem.owner
    local simple,complex=inst.components.projectile,inst.components.complexprojectile
    local projectile = simple and simple:IsThrown() or complex and
        (complex.velocity.x~=0 or complex.velocity.y~=0 or complex.velocity.z~=0)
    item=item and not projectile
    local effect = inst:HasTag("FX") or inst:HasTag("fx")
    if inst:HasTag("NOCLICK") and not projectile and not effect then return nil end
    local group = inst.Physics and inst.Physics:GetCollisionGroup()
    local preview=require("starvecraft/actions").Preview(inst,nearby)
    local info=classifications[inst]
    if not info then info={};classifications[inst]=info end
    info.work=WorkCode(inst)
    info.attack=inst.components.combat~=nil and inst.components.health~=nil and not inst.components.health:IsDead()
    info.solid=not item and not projectile and group==COLLISION.OBSTACLES
    info.body=not item and not projectile and group==COLLISION.CHARACTERS
    info.pick,info.offers=preview.scene,preview.offers
    info.name=preview.name
    info.item=item and true or false
    info.visual=projectile or (effect and not item)
    if info.work or info.attack or info.solid or info.body or info.item or info.visual or info.pick
        or inst.components.inspectable or inst.components.pickable or PROFILES[inst.prefab] then
        return info
    end
end

local snapshot_seq = 0

local last_art, asset_cache = {}, {}
local snapshot_rows={}
local WHITE={1,1,1,1}
local function Assets(prefab)
    if asset_cache[prefab] then return asset_cache[prefab] end
    local files = {}
    local definition = Prefabs[prefab]
    for _, a in ipairs(definition and definition.assets or {}) do
        if a.type == "ANIM" and a.file:match("^anim/[%w_%-]+%.zip$") then
            table.insert(files, a.file:sub(6))
        end
    end
    asset_cache[prefab] = files
    return files
end
M.Assets=Assets

local ground_cache
local function Ground(px,pz,terrain)
    local map, tiles = GetWorld().Map, {}
    local gx,gy,gz=map:GetTileCenterPoint(px,0,pz)
    if ground_cache and ground_cache.map==terrain and ground_cache.x==gx and ground_cache.z==gz then return ground_cache.tiles end
    for x = px-32, px+32, 4 do
        for z = pz-32, pz+32, 4 do
            local cx, _, cz = map:GetTileCenterPoint(x, 0, z)
            local info = GetTileInfo(map:GetTileAtPoint(cx, 0, cz))
            if info then
                local mx, _, mz = mcbridge.ToMC(cx, 0, cz)
                table.insert(tiles, {x=mx, z=mz, material=info.name, noise=info.noise_texture})
            end
        end
    end
    ground_cache={map=terrain,x=gx,z=gz,tiles=stream.Immutable(tiles)}
    return tiles
end

local function Observe(inst,player,px,pz,mc_session,reach)
        local entry=snapshot_rows[inst.GUID]
        if not entry then entry={data={art={}},revision=0};snapshot_rows[inst.GUID]=entry end
        entry.exportable=false
        if not inst:IsValid() then return entry end
        local transform,physics=inst.Transform,inst.Physics
        local x,y,z=transform:GetWorldPosition()
        local radius=physics and physics:GetRadius() or .4
        -- Refresh native action previews before MC can reach the body's bounding box.
        local interactive=not reach or (x-px)^2+(z-pz)^2<=(reach+math.max(.2,radius)*1.414214)^2
        local info = Classify(inst, player, interactive)
        local st = info and animtrack.Get(inst,last_art[inst.GUID])
        if st and st.anim ~= "?" and st.bank and st.build then last_art[inst.GUID] = st end
        st = st and st.anim ~= "?" and st or last_art[inst.GUID]
        if info and st and st.bank and st.build then
            local mx, my, mz = mcbridge.ToMC(x, y, z)
            local shape, vw, vh = Profile(inst, radius)
            local sx, sy = transform:GetScale()
            local row=entry.data
            local art=row.art
            if entry.visual_revision~=st.revision or art.anim~=st.anim or art.generation~=(st.generation or 0) or row.prefab~=inst.prefab then
            entry.visual_revision=st.revision;entry.revision=entry.revision+1
            Set(entry,art,"bank",st.bank);Set(entry,art,"build",st.build);Set(entry,art,"files",Assets(inst.prefab))
            Set(entry,art,"anim",st.anim);Set(entry,art,"loop",st.loop);Set(entry,art,"generation",st.generation or 0)
            Set(entry,art,"overrides",st.overrides);Set(entry,art,"hidden",st.hidden);Set(entry,art,"colour",st.colour or WHITE)
            Set(entry,art,"ground",st.ground or false);Set(entry,art,"layer",st.layer or 0);Set(entry,art,"sort",st.sort or 0)
            end
            art.percent,art.rotation=st.percent or 0,transform:GetRotation()
            Set(entry,art,"sx",sx or 1);Set(entry,art,"sy",sy or 1)
            Set(entry,row,"id",inst.GUID);Set(entry,row,"prefab",inst.prefab);Set(entry,row,"name",info.name)
            row.x,row.y,row.z=mx,my,mz
            Set(entry,row,"width",math.max(.4,radius*2));Set(entry,row,"height",math.max(.5,vh*.9))
            Set(entry,row,"shape",shape);Set(entry,row,"vw",vw);Set(entry,row,"vh",vh)
            Set(entry,row,"solid",info.solid);Set(entry,row,"body",info.body);Set(entry,row,"work",info.work or "-")
            Set(entry,row,"attack",info.attack);Set(entry,row,"pick",info.pick);Set(entry,row,"item",info.item)
            Set(entry,row,"visual",info.visual and true or false);Set(entry,row,"speech",items.Speech(inst))
            Set(entry,row,"map_icon",animtrack.MapIcon(inst))
            if not row.use_items or row.use_items[1]~=info.offers[1] or row.use_items[2]~=info.offers[2] then Set(entry,row,"use_items",info.offers) end
            Set(entry,row,"motion_session",mc_session);Set(entry,row,"motion_ack",inst.sc_contact_session==mc_session and inst.sc_contact_ack or 0)
            entry.exportable=true
        end
        return entry
end

local samples,latest,sample_cursor={},{},1
function M.Sample()
    if not link.Active() then return end
    if sample_cursor>#samples then samples=latest;sample_cursor=1 end
    local player=GetPlayer();local px,py,pz=player.Transform:GetWorldPosition()
    local reach=mcbridge.pose and mcbridge.pose.interaction_range
    for i=1,math.ceil(#samples/3) do
        local inst=samples[sample_cursor];if not inst then break end
        sample_cursor=sample_cursor+1
        local entry=snapshot_rows[inst.GUID];local row=entry and entry.data
        if not row or not (row.body or row.item or row.visual) then Observe(inst,player,px,pz,link.McSession(),reach) end
    end
end

function M.ExportSnapshot()
    -- Complete contact before sampling physical bodies and acknowledging their MC displacement.
    for inst in pairs(active_contacts) do FinishContact(inst) end
    local player=GetPlayer();local px,py,pz=player.Transform:GetWorldPosition()
    local entities,lines,revisions={},{},{}
    local nearby=TheSim:FindEntities(px,py,pz,ExportRadius())
    latest=nearby
    local mc_session=link.McSession();local reach=mcbridge.pose and mcbridge.pose.interaction_range
    local mx,my,mz=mcbridge.ToMC(px,py,pz)
    for _,inst in ipairs(nearby) do
        local entry=snapshot_rows[inst.GUID];local row=entry and entry.data
        local close=row and row.x and (not reach or (row.x-mx)^2+(row.z-mz)^2<=(reach+row.width*.707107)^2)
        if not entry or close or row.body or row.item or row.visual then entry=Observe(inst,player,px,pz,mc_session,reach) end
        if entry.exportable then
            revisions[inst.GUID]=entry.revision;entities[#entities+1]=entry.data
            lines[#lines+1]=inst.GUID.." "..inst.prefab
        end
    end
    snapshot_seq = snapshot_seq + 1
    M.exported = lines
    local terrain=stream.Immutable(require("starvecraft/terrain").Export())
    local scene = {version=1, pair=link.PairId(), session=link.session, seq=snapshot_seq,terrain=terrain,
        surface_speed=require("starvecraft/surface").speed,overlays=require("starvecraft/surface").Patches(player),travel=require("starvecraft/travel").Snapshot(),
        cave=GetWorld():IsCave(),time=GetTime(), clock=McTime() or 0, weather=require("starvecraft/weather").Snapshot(),ui=require("starvecraft/nativeui").Snapshot(),ground=Ground(px,pz,terrain), entities=entities,lights=M.LightSnapshot(px,pz),activity=require("starvecraft/activity").Snapshot(player)}
    local pose=mcbridge.pose
    local ack=pose and pose.scene_session==link.session and pose.scene_ack or 0
    WriteFile("ds_scene.json", "seq " .. snapshot_seq .. "\n" .. stream.Encode(scene,ack,revisions) .. "\nend " .. snapshot_seq .. "\n")
    for id in pairs(snapshot_rows) do if not Ents[id] then last_art[id]=nil;snapshot_rows[id]=nil end end
end

-- ------------------------------------------------------------ 执行 MC 的动作

-- 工具能做的饥荒工作：斧头砍树，镐挖矿/拆，锹挖树桩和草，空手也能撸树（MC 的老传统）
local TOOL_ACTIONS = {}

local HANDLERS = {}

FinishContact=function(inst)
    local move=active_contacts[inst]
    if not move then return end
    active_contacts[inst]=nil
    if inst:IsValid() then
        inst.Physics:ClearMotorVelOverride()
        inst.sc_contact_ack=move.seq
    end
end

function HANDLERS.body_move(id,seq,x,z)
    local inst=Ents[tonumber(id)]
    seq,x,z=tonumber(seq),tonumber(x),tonumber(z)
    if inst and inst:IsValid() and inst.Physics and inst.Physics:GetCollisionGroup()==COLLISION.CHARACTERS
        and seq and seq>0 and seq==math.floor(seq) and seq<9007199254740991
        and x and z and x==x and z==z and math.abs(x)<=1 and math.abs(z)<=1 then
        if inst.sc_contact_session~=link.McSession() then
            FinishContact(inst)
            inst.sc_contact_session,inst.sc_contact_ack,inst.sc_contact_seen=link.McSession(),0,0
        end
        if seq<=inst.sc_contact_seen then return end
        inst.sc_contact_seen=seq
        local move=queued_contacts[inst] or {x=0,z=0}
        move.x,move.z,move.seq=move.x+x,move.z+z,seq
        queued_contacts[inst]=move
    end
end

local function ApplyContacts()
    for inst,move in pairs(queued_contacts) do
        if inst:IsValid() then
            if inst.sg and inst.sg:HasStateTag("busy") then inst.sc_contact_ack=move.seq
            else
                if inst.sg and inst.sc_contact_hook~=inst.sg then
                    local go=inst.sg.GoToState
                    function inst.sg:GoToState(...)
                        FinishContact(inst)
                        return go(self,...)
                    end
                    inst.sc_contact_hook=inst.sg
                end
                local vx,vy,vz=inst.Physics:GetMotorVel()
                local angle=inst.Transform:GetRotation()*DEGREES
                inst.Physics:SetMotorVelOverride(vx+(move.x*math.cos(angle)+move.z*math.sin(angle))/.1,vy,
                    vz+(move.x*math.sin(angle)-move.z*math.cos(angle))/.1)
                active_contacts[inst]=move
            end
        end
        queued_contacts[inst]=nil
    end
end

function HANDLERS.work(id, tool, amount)
    local inst = Ents[tonumber(id)]
    local w = inst and inst:IsValid() and inst.components.workable
    if not (w and w:CanBeWorked()) then
        return
    end
    local allowed = TOOL_ACTIONS[tool]
    if allowed and allowed[w.action] then
        amount = tonumber(amount)
        if not amount or amount <= 0 or amount > 100 then return end
        local player=GetPlayer()
        local action=BufferedAction(player,inst,w.action)
        local original=action.Do
        function action:Do(...)
            local previous=player.components.worker
            -- Native actions read worker effectiveness when no native inventory tool is involved.
            player.components.worker={GetEffectiveness=function() return amount end}
            local ok,success,reason=pcall(original,self,...)
            player.components.worker=previous
            if not ok then error(success) end
            return success,reason
        end
        require("starvecraft/activity").Execute(action,function() end)
    end
end

function HANDLERS.attack(id, damage)
    local inst = Ents[tonumber(id)]
    damage = tonumber(damage)
    if not damage or damage <= 0 or damage > 1000 then return end
    if inst and inst:IsValid() and inst.components.combat and inst.components.health
        and not inst.components.health:IsDead() then
        inst.components.combat:GetAttacked(GetPlayer(), compat.ToDS(damage))
    end
end

function HANDLERS.pick(id)
    local inst = Ents[tonumber(id)]
    if not inst or not inst:IsValid() or not inst:IsNear(GetPlayer(), 4) then return end
    local action=require("starvecraft/actions").Scene(inst)
    if action then require("starvecraft/activity").Execute(action,function() end) end
end
HANDLERS.ui_close=function(id) require("starvecraft/nativeui").Close(id) end

local function HandleEvent(payload)
    local action, body, pose_seq=payload:match("^([%w_]+) (.-) (%d+)$")
    if action=="craft" or action=="drop_native" or action=="item_action" or action=="ui_action" or action=="armor_damage" then
        pose_seq=tonumber(pose_seq)
        if not mcbridge.pose or mcbridge.pose.seq<pose_seq then return false end
        if mcbridge.pose.seq-pose_seq>40 or not require("starvecraft/invasion").Sync() then return end
        local ok,request=pcall(json.decode,body)
        if ok and type(request)=="table" then
            request.player_seq=pose_seq
            if action=="craft" then crafting.Execute(request)
            elseif action=="item_action" then require("starvecraft/equipment").Execute(request)
            elseif action=="ui_action" then require("starvecraft/nativeui").Execute(request)
            elseif action=="armor_damage" then require("starvecraft/invasion").Armor(request)
            else items.ReturnDrop(request) end
        end
        return
    end
    local args = {}
    for w in payload:gmatch("%S+") do
        table.insert(args, w)
    end
    local actor_seq = tonumber(table.remove(args))
    if not actor_seq or actor_seq < 0 or actor_seq ~= math.floor(actor_seq) then return end
    if not mcbridge.pose or mcbridge.pose.seq < actor_seq then return false end
    if mcbridge.pose.seq - actor_seq > 40 then return end
    if not require("starvecraft/invasion").Sync() then return end
    local fn = HANDLERS[table.remove(args, 1)]
    if fn then
        local ok, err = pcall(fn, unpack(args))
        if not ok then
            print("[StarveCraft] mc event error:", payload, err)
            error(err)
        end
    end
end

-- ------------------------------------------------------------ 回传掉落与受伤

-- Native ground loot stays native. Only an inventory transfer crosses to MC.
local function HookPlayerInventory(player, active)
    local inventory = player.components.inventory
    local give = inventory.GiveItem
    function inventory:GiveItem(item, ...)
        if crafting.Projecting() then return give(self,item,...) end
        if item and crafting.Capture(item) then return true end
        if not active() or not item or not item.components.inventoryitem then
            return give(self, item, ...)
        end
        local spec=require("starvecraft/inventory").Keep(item)
        Send("native_item " .. json.encode(spec))
        return true
    end
    local equip=inventory.Equip
    function inventory:Equip(item,...)
        if require("starvecraft/equipment").projecting then return equip(self,item,...) end
        if item and crafting.Capture(item) then return true end
        return equip(self,item,...)
    end
end

-- ------------------------------------------------------------ 入口

-- active()：MC 当前是否在驱动（只有这时才同步，MC 没开时一切照旧）
function M.Install(player, active)
    WORK_CODES[ACTIONS.CHOP] = "C"
    WORK_CODES[ACTIONS.MINE] = "M"
    WORK_CODES[ACTIONS.DIG] = "D"
    WORK_CODES[ACTIONS.HAMMER] = "H"
    TOOL_ACTIONS.axe = { [ACTIONS.CHOP] = true }
    TOOL_ACTIONS.hand = { [ACTIONS.CHOP] = true }
    TOOL_ACTIONS.pickaxe = { [ACTIONS.MINE] = true, [ACTIONS.HAMMER] = true }
    TOOL_ACTIONS.shovel = { [ACTIONS.DIG] = true }

    HookPlayerInventory(player, active)
    -- Read distant static sprites across native ticks, retaining the same 10 Hz observation rate.
    player:DoPeriodicTask(GetTickTime()+GetTickTime()*1e-6,M.Sample)
    -- The native scheduler floors wake ticks; preserve the intended 100ms instead of rounding to two ticks.
    player:DoPeriodicTask(.1+GetTickTime()*1e-6, function()
        if active() then
            items.PlayerSpeech(player)
            crafting.Export()
            M.ExportSnapshot()
            PollEvents(HandleEvent)
            ApplyContacts()
        end
    end)
end

return M
