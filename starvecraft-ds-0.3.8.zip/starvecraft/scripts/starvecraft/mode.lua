-- Only an explicitly running test client can select the test namespace.
local M = {}
local f = io.open(STARVECRAFT.MODROOT .. "devio/mc_link.txt", "r")
local text = f and f:read("*a") or ""
if f then f:close() end
local phase, beat, mode = text:match("^(%S+) %S+ %-?%d+ (%d+) %S+ (%S+)")
local requested = Settings and Settings.starvecraft_mode
if requested ~= "play" and requested ~= "test" then
    local fresh = beat ~= nil and math.abs(os.time() * 2 - tonumber(beat)) < 20
    local driving = phase == "want" or phase == "in" or phase == "saving"
    requested = fresh and driving and mode == "test" and "test" or "play"
end
M.name = requested
M.testing = requested == "test"
print("[StarveCraft] namespace", requested, "request", phase, mode, beat, "now", os.time(), "instance", Settings and Settings.starvecraft_mode)
return M
