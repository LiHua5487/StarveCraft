-- Delete only an acknowledged MC pair, through the current namespace's native save index.
local M={}
local json=require("json")
local channel=require("starvecraft/channel")
local busy=false
local last_ack=""
local function ValidId(id) return type(id)=="string" and #id>0 and #id<=128 and id:match("^[%w_%-]+$") end
local function Find(pair)
    for slot,data in ipairs(SaveGameIndex.data.slots) do
        if data.starvecraft and data.starvecraft.id==pair then return slot end
    end
end
local function Requests()
    local mode=STARVECRAFT.MODE
    local prefix=mode=="test" and "starvecraft_unified_" or "starvecraft_play_"
    if (mode~="play" and mode~="test") or SaveGameIndex:GetSaveIndexName():sub(1,#prefix)~=prefix then return end
    local text=channel.Read("mc_deletions_"..mode..".json")
    local ok,body=pcall(json.decode,text or "")
    if not ok or type(body)~="table" or body.version~=1 or body.mode~=mode or type(body.requests)~="table" or #body.requests>256 then return end
    for _,request in ipairs(body.requests) do
        if type(request)~="table" or not ValidId(request.id) or not ValidId(request.pair) then return end
    end
    return body.requests
end
local function Ack(requests)
    local receipts=SaveGameIndex.data.starvecraft_deletions or {}
    local done={}
    for _,request in ipairs(requests) do
        if receipts[request.id]==request.pair then table.insert(done,{id=request.id,pair=request.pair}) end
    end
    local text=json.encode({version=1,mode=STARVECRAFT.MODE,done=done}).."\n"
    if text~=last_ack then
        local ok=pcall(channel.Write,"ds_deletions_"..STARVECRAFT.MODE..".json",text)
        if ok then last_ack=text end
    end
end
function M.Poll(current_pair,leave_world)
    if busy then return true end
    local requests=Requests()
    if not requests then return false end
    local receipts=SaveGameIndex.data.starvecraft_deletions or {}
    SaveGameIndex.data.starvecraft_deletions=receipts
    for _,request in ipairs(requests) do
        if receipts[request.id]~=request.pair then
            local slot=Find(request.pair)
            if slot and current_pair and (current_pair==request.pair or slot==SaveGameIndex:GetCurrentSaveSlot()) then leave_world();return true end
            local function Completed(success)
                if success==false or Find(request.pair) then busy=false;return end
                receipts[request.id]=request.pair
                SaveGameIndex:Save(function(saved)
                    busy=false
                    if saved==false then receipts[request.id]=nil else Ack(requests) end
                end)
            end
            busy=true
            if slot then SaveGameIndex:DeleteSlot(slot,Completed,false) else Completed() end
            return true
        end
    end
    Ack(requests)
    return false
end
return M
