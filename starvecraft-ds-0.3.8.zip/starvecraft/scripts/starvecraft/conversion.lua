-- Explicit recipes are the only place where a native item changes engine identity.
local M={}
local definitions={}
function M.Recipes()
    local items=require("starvecraft/items")
    local tab={slot=31,id="CONVERSION",name="物品转换",atlas="images/inventoryimages.xml",image="rocks.tex"}
    local recipes,reverse={},{}
    local names={}
    for prefab in pairs(require("starvecraft/compat").LOOT_TO_MC) do table.insert(names,prefab) end
    table.sort(names)
    for _,prefab in ipairs(names) do
        local mc=require("starvecraft/compat").LOOT_TO_MC[prefab]
        local native=items.Equivalent(prefab);native.count=1
        local output=deepcopy(native);output.converted_mc=mc
        local name="convert_"..prefab.."_to_mc"
        local recipe={name=name,tab=tab,ingredients={deepcopy(native)},output=output,allowed=true,show=true,conversion="to_mc"}
        definitions[name]={prefab=prefab,mc=mc,to_mc=true};table.insert(recipes,recipe)
        -- Multiple native items can map to one MC item; only one reverse recipe may match that grid.
        local preferred=require("starvecraft/compat").CONVERSION_REVERSE
        if not reverse[mc] and (not preferred or not preferred[mc] or preferred[mc]==prefab) then
            reverse[mc]=true
            local input=deepcopy(native);input.converted_mc=mc;input.mc_input=mc
            name="convert_"..prefab.."_to_ds"
            definitions[name]={prefab=prefab,mc=mc,to_mc=false}
            table.insert(recipes,{name=name,tab=tab,ingredients={input},output=deepcopy(native),allowed=true,show=true,conversion="to_ds"})
        end
    end
    return recipes
end
function M.Execute(request,result)
    local rule=definitions[request.recipe]
    if not rule then return false end
    local spec=type(request.inputs)=="table" and #request.inputs==1 and request.inputs[1]
    if type(spec)~="table" or spec.count~=1 or spec.prefab~=rule.prefab then return true end
    local store=require("starvecraft/inventory")
    if rule.to_mc then
        if spec.origin=="mc" then return true end
        local original=store.Find(spec)
        if not original or original.prefab~=rule.prefab then return true end
        local item=require("starvecraft/equipment").Acquire(spec)
        if not item then return true end
        local output={prefab=rule.prefab,count=1,converted_mc=rule.mc}
        local condition=item.components.finiteuses or item.components.fueled or item.components.armor
        if condition and condition.GetPercent then output.condition=condition:GetPercent() end
        require("starvecraft/equipment").Detach(item);item:Remove()
        result.outputs={output};result.ok=true
    elseif spec.origin=="mc" and spec.mc==rule.mc then
        local item=spec.item_id and require("starvecraft/equipment").Acquire(spec) or SpawnPrefab(rule.prefab)
        if not item then return true end
        item.sc_mc_origin=nil;item.sc_mc_stack=nil;item.sc_mc_prefab=nil
        local condition=item.components.finiteuses or item.components.fueled or item.components.armor
        if spec.condition and condition and condition.SetPercent then condition:SetPercent(math.max(.0001,math.min(1,spec.condition))) end
        result.outputs={store.Keep(item)};result.ok=true
    end
    return true
end
return M
