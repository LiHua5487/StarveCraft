-- MC owns the slots; native inventory/container ownership keeps each item alive.
local M={live={},busy={},projecting=false,OFFHAND="sc_offhand"}
local store=require("starvecraft/inventory")
local link=require("starvecraft/link")
local bridge=require("starvecraft/mcbridge")
local json=require("json")
local inflight={}

function M.NativeSlot(item)
    local equip=item and item.components.equippable
    return equip and (item.sc_mc_native_equip_slot or equip.equipslot)
end
local function SetSlot(item,slot)
    local equip=item.components.equippable
    if slot==M.OFFHAND then
        item.sc_mc_native_equip_slot=M.NativeSlot(item)
        equip.equipslot=slot
    elseif item.sc_mc_native_equip_slot then
        equip.equipslot=item.sc_mc_native_equip_slot
        item.sc_mc_native_equip_slot=nil
    end
end
local function Equip(inventory,item,slot)
    SetSlot(item,slot)
    local previous=M.projecting;M.projecting=true
    local ok,result=pcall(inventory.Equip,inventory,item)
    M.projecting=previous
    if not ok then error(result) end
    return result
end

-- Native Inventory already supports named equipment slots and persists their real items.
function M.HookEquippable(component)
    local save,load,unequip=component.OnSave,component.OnLoad,component.Unequip
    function component:OnSave(...)
        local data,refs
        if save then data,refs=save(self,...) end
        if self.inst.sc_mc_native_equip_slot then
            data=data or {};data.sc_mc_native_equip_slot=self.inst.sc_mc_native_equip_slot
        end
        return data,refs
    end
    function component:OnLoad(data,...)
        if load then load(self,data,...) end
        if data and data.sc_mc_native_equip_slot==EQUIPSLOTS.HANDS then
            self.inst.sc_mc_native_equip_slot=EQUIPSLOTS.HANDS;self.equipslot=M.OFFHAND
        end
    end
    function component:Unequip(...)
        local result=unequip(self,...)
        SetSlot(self.inst,M.NativeSlot(self.inst))
        return result
    end
end

function M.HookInventoryBar(bar)
    bar:AddEquipSlot(M.OFFHAND,"images/hud.xml","equip_slot.tex")
    local equip,refresh=bar.OnItemEquip,bar.Refresh
    local function ready(self,slot)
        -- The minimized/hidden HUD may not run OnUpdate's deferred native rebuild.
        if not self.equip[slot or M.OFFHAND] then self:Rebuild() end
    end
    function bar:OnItemEquip(item,slot)
        ready(self,slot)
        return equip(self,item,slot)
    end
    function bar:Refresh(...)
        ready(self)
        return refresh(self,...)
    end
end

-- Old saves and MC-only inputs enter once, rather than once per use.
function M.Restore(spec) return store.Import(spec) end
function M.Remember(item,id)
    return item and item:IsValid() and store.Describe(item) or {removed=true,item_id=id,count=0}
end
function M.SyncCondition(item,spec,initial)
    if not item or not item:IsValid() or item.sc_mc_origin~="mc" or type(spec)~="table" then return end
    local percent=spec.condition
    local component=item.components.finiteuses or item.components.armor or item.components.fueled
    if not component or not component.SetPercent or type(percent)~="number" or percent~=percent or percent<0 or percent>1 then return end
    local basis=spec.condition_basis or spec.revision or 0
    local base=spec.condition_base or percent
    if type(basis)~="number" or basis<0 or basis>9007199254740991 or basis~=math.floor(basis)
        or type(base)~="number" or base~=base or base<0 or base>1 then return end
    local session=link.McSession()
    local sequence=spec.condition_seq or bridge.pose and bridge.pose.seq or 0
    if type(sequence)~="number" or sequence<0 or sequence>9007199254740991 or sequence~=math.floor(sequence) then return end
    if initial then
        item.sc_mc_condition_total=0;item.sc_mc_condition_basis=basis;item.sc_mc_condition_last=percent
        item.sc_mc_condition_session=session;item.sc_mc_condition_seq=sequence
        component:SetPercent(percent)
        return
    end
    if item.sc_mc_condition_session~=session then item.sc_mc_condition_session=session;item.sc_mc_condition_seq=-1 end
    if sequence<(item.sc_mc_condition_seq or -1) or basis<(item.sc_mc_condition_basis or -1) then return end
    local previous=basis==item.sc_mc_condition_basis and item.sc_mc_condition_last or base
    if sequence==item.sc_mc_condition_seq and basis==item.sc_mc_condition_basis and previous and percent>previous then return end
    local difference=percent-(previous or base)
    item.sc_mc_condition_seq=sequence;item.sc_mc_condition_basis=basis;item.sc_mc_condition_last=percent
    if difference~=0 then
        item.sc_mc_condition_total=(item.sc_mc_condition_total or 0)+difference
        component:SetPercent(math.max(0,math.min(1,component:GetPercent()+difference)))
    end
end
function M.Acquire(spec)
    if type(spec)~="table" then return end
    for _,entry in pairs(M.live) do
        if spec.item_id and entry.id==spec.item_id and entry.item:IsValid() then
            M.SyncCondition(entry.item,spec)
            if not entry.item:IsValid() then return end
            local amount=entry.item.components.stackable and entry.item.components.stackable:StackSize() or 1
            local count=spec.count or amount
            if count<amount then return store.Take(spec),true end
            if count==amount then return entry.item,false end
            return
        end
    end
    if not spec.managed then
        local item=store.Import(spec)
        if not item then return end
        spec={item_id=store.Id(item),count=spec.count or 1,managed=true}
    end
    local current=store.Find(spec)
    if current then M.SyncCondition(current,spec) end
    return store.Take(spec),true
end
function M.Detach(item)
    for slot,entry in pairs(M.live) do
        if entry.item==item then GetPlayer().components.inventory:Unequip(slot);M.live[slot]=nil end
    end
    store.Detach(item)
end
local function first(actions)
    for _,action in ipairs(actions or {}) do
        if action.action~=ACTIONS.DROP and action.action~=ACTIONS.WALKTO and action.action~=ACTIONS.LOOKAT
            and action.action~=ACTIONS.EQUIP and action.action~=ACTIONS.UNEQUIP then return action end
    end
end

-- Use the real items worn when MC accepted this hit, without replaying equip callbacks.
function M.ArmorEquipment(specs)
    if type(specs)~="table" or #specs>3 then return end
    local slots,seen={},{}
    for key,spec in pairs(specs) do
        if type(key)~="number" or key<1 or key>#specs or key~=math.floor(key)
            or type(spec)~="table" or type(spec.item_id)~="string" or seen[spec.item_id] then return end
        local item=store.Find(spec)
        local equip=item and item.components.equippable
        if not equip or tostring(M.NativeSlot(item))~=spec.equip
            or not (item.components.armor or item.components.resistance) or slots[equip.equipslot] then return end
        seen[spec.item_id]=true;slots[equip.equipslot]=item
    end
    return slots
end
local function Execute(request)
    if type(request)~="table" or type(request.id)~="string" or not request.id:match("^[%w%-]+$") or #request.id>64 then return end
    local player=GetPlayer()
    local receipts=player.components.builder.sc_receipts
    local function reply(result) require("starvecraft/channel").Send("craft_result "..json.encode(result)) end
    if receipts[request.id] then reply(receipts[request.id]);return end
    if inflight[request.id] then return end
    local strength=request.strength==nil and 1 or tonumber(request.strength)
    if not strength or strength~=strength or strength<0 or strength>1000 or type(request.item)~="table" then return end
    if request.target_item~=nil and type(request.target_item)~="table" then return end
    request.item.condition_seq=request.player_seq
    if request.target_item and (request.target_item.item_id==request.item.item_id
        or store.Find(request.target_item)==store.Find(request.item) and store.Find(request.item)~=nil) then
        local denied={id=request.id,ok=false,outputs={}};receipts[request.id]=denied;reply(denied);return
    end
    request.item.import_id=request.item.import_id or request.id
    local item,borrowed=M.Acquire(request.item)
    local result={id=request.id,ok=true,outputs={}}
    if not item then result.ok=false;receipts[request.id]=result;reply(result);return end
    inflight[request.id]=true
    local inventory=player.components.inventory
    if borrowed and request.mainhand==true and M.NativeSlot(item)==EQUIPSLOTS.HANDS then
        local original=item
        Equip(inventory,item,EQUIPSLOTS.HANDS)
        item=inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
        if item then
            borrowed=false
            local id=store.Id(item)
            M.live[EQUIPSLOTS.HANDS]={item=item,id=id,previous=id~=request.item.item_id and request.item.item_id or nil}
            if original~=item and original:IsValid() then table.insert(result.outputs,store.Keep(original)) end
        else item=original end
    end
    if borrowed then inventory:GiveActiveItem(item) end
    local inventory_target=request.target_item and store.Find(request.target_item)
    local target=inventory_target or Ents[tonumber(request.target)]
    local picker=player.components.playeractionpicker
    local action,used_action
    if target and target:IsValid() and (inventory_target or target:IsNear(player,4)) then
        if request.work and target.components.workable and target.components.workable:CanBeWorked() and item.components.tool
            and item.components.tool:CanDoAction(target.components.workable.action) then
            action=BufferedAction(player,target,target.components.workable.action,item)
        else
            if request.right then action=require("starvecraft/actions").Item(target,item)
            else action=first(picker:GetEquippedItemActions(target,item,false)) end
        end
    elseif request.block=="EAT" and item.components.edible and player.components.eater:CanEat(item) then
        action=BufferedAction(player,nil,ACTIONS.EAT,item)
    elseif request.block and item.components.tool then
        local native=ACTIONS[request.block]
        if native and item.components.tool:CanDoAction(native) then used_action=native end
    elseif request.x and request.z then
        local x,z=tonumber(request.x),tonumber(request.z)
        if x and z and x==x and z==z and math.abs(x)<1000000 and math.abs(z)<1000000 then
            local dx,_,dz=bridge.ToDS(x,0,z)
            local pt=Vector3(dx,0,dz)
            if player:GetDistanceSqToPoint(pt)<25 then
                -- DEPLOY validates the actual point itself, without consulting the backend window's mouse.
                action=item.components.deployable and BufferedAction(player,nil,ACTIONS.DEPLOY,item,pt)
                    or first(picker:GetPointActions(pt,item,true)) or first(picker:GetPointActions(pt,item,false))
            end
        end
    elseif not request.target and not request.target_item then
        action=first(picker:GetInventoryActions(item,true)) or first(picker:GetInventoryActions(item,false))
    end
    local crafting=require("starvecraft/crafting")
    local invasion=require("starvecraft/invasion")
    local activity=require("starvecraft/activity")
    local immediate=activity.IsImmediate(action)
    local identity=store.Id(item)
    M.busy[identity]=request.id
    local finished=false
    local function finish(success)
        if finished then return end
        finished=true;M.busy[identity]=nil;inflight[request.id]=nil;result.action_ok=success and true or false
        if item:IsValid() and item.components.inventoryitem then
            local owner=item.components.inventoryitem.owner
            if borrowed and owner==player then result.replacement=store.Keep(item)
            elseif not borrowed and owner==player then result.replacement=store.Describe(item)
            else result.replacement={removed=true,item_id=identity,count=0};item.persists=true end
        else result.replacement={removed=true,item_id=identity,count=0} end
        receipts[request.id]=result;reply(result)
    end
    local function completed(success)
        if (borrowed or request.work) and not immediate then
            activity.WhenIdle(player,function() finish(success) end)
        else finish(success) end
    end
    local function perform(fn,...)
        local previous_outputs,previous_action=crafting.outputs,invasion.native_action
        crafting.outputs={};invasion.BeginEffects();invasion.native_action=true
        local ok,success,reason=pcall(fn,...)
        invasion.native_action=previous_action
        local effects=invasion.EndEffects();if next(effects) then result.effects=effects end
        local outputs=crafting.outputs;crafting.outputs=previous_outputs
        for _,output in ipairs(outputs) do
            if output:IsValid() and output~=item then table.insert(result.outputs,store.Keep(output)) end
        end
        if not ok then finish(false);error(success) end
        return success,reason
    end
    if used_action then
        result.action=used_action.id;perform(item.OnUsedAsItem,item,used_action);finish(true)
    elseif action and action.action==ACTIONS.ATTACK then
        if activity.CanAct(player) then
            result.action=action.action.id;perform(player.components.combat.DoAttack,player.components.combat,target,item,nil,nil,strength);finish(true)
        else finish(false) end
    elseif action then
        result.action=action.action.id
        local original=action.Do
        action.Do=function(self,...)
            local ok,success,reason=pcall(perform,original,self,...)
            if not ok then inflight[request.id]=nil;M.busy[identity]=nil;error(success) end
            return success,reason
        end
        activity.Execute(action,completed)
    else finish(false) end
end
function M.Execute(request)
    local ok,err=pcall(Execute,request)
    if not ok then
        if type(request)=="table" and type(request.id)=="string" then
            inflight[request.id]=nil
            for id,owner in pairs(M.busy) do if owner==request.id then M.busy[id]=nil end end
        end
        error(err)
    end
end
function M.Sync(player,specs)
    -- A native action owns its equipment until completion; the next observation applies any hand swap.
    if next(M.busy) then return end
    local inventory=player.components.inventory
    local wanted,updates,retained={},{},{}
    for _,spec in ipairs(specs or {}) do
        local slot=spec.mc_slot=="offhand" and spec.equip=="hands" and M.OFFHAND or spec.equip or EQUIPSLOTS.HANDS
        wanted[slot]=spec
    end
    for slot,entry in pairs(M.live) do
        local target,spec
        for candidate,value in pairs(wanted) do
            if value.item_id==entry.id or value.item_id==entry.previous then target,spec=candidate,value;break end
        end
        local owned=entry.item:IsValid() and entry.item.components.inventoryitem
            and entry.item.components.inventoryitem.owner==player and inventory.equipslots[slot]==entry.item
        if target and owned then
            if spec.item_id==entry.id then entry.previous=nil end
            retained[target]=entry
            if not spec.request then M.SyncCondition(entry.item,spec) end
        elseif owned then table.insert(updates,store.Keep(entry.item)) end
    end
    -- Swapping MC hands keeps the same native objects equipped, including fuel, follower FX and callbacks.
    local moved=false
    for slot,entry in pairs(M.live) do
        if retained[slot]~=entry and inventory.equipslots[slot]==entry.item then inventory.equipslots[slot]=nil;moved=true end
    end
    for slot,entry in pairs(retained) do SetSlot(entry.item,slot);inventory.equipslots[slot]=entry.item end
    M.live=retained
    local bar=player.HUD and player.HUD.controls and player.HUD.controls.inv
    if moved and bar then bar:Refresh() end
    for slot,spec in pairs(wanted) do
        if not M.live[slot] and not spec.request then
            local item=M.Acquire(spec)
            if item and item.components.equippable and tostring(M.NativeSlot(item))==(spec.equip or "hands") then
                Equip(inventory,item,slot)
                local id=store.Id(item)
                M.live[slot]={item=item,id=id,previous=id~=spec.item_id and spec.item_id or nil}
                local update=store.Describe(item)
                if id~=spec.item_id then update.previous_item_id=spec.item_id;update.equipment_slot=tostring(slot) end
                table.insert(updates,update)
            elseif item then store.Keep(item) end
        end
    end
    if #updates>0 then require("starvecraft/channel").Send("equipment "..json.encode(updates)) end
end
function M.Install(player)
    for slot,item in pairs(player.components.inventory.equipslots) do
        if item.sc_item_id then store.Track(item);M.live[slot]={item=item,id=store.Id(item)} end
    end
    player:DoPeriodicTask(.1,function()
        if link.Active() and bridge.pose then M.Sync(player,bridge.pose.equipment) end
    end)
end
return M
