-- Native SG owns action timing and cancellation; MC owns the player's actual motion.
local M={}
local states=setmetatable({}, {__mode="k"})
local immediate={PICK=true,PICKUP=true,HARVEST=true,PLANT=true,DEPLOY=true,EAT=true}
local resource_work={CHOP=true,MINE=true,DIG=true,HAMMER=true}

function M.IsImmediate(action)
    if not action then return false end
    if immediate[action.action.id] then return true end
    local workable=action.target and action.target.components.workable
    return resource_work[action.action.id] and workable and workable:CanBeWorked()
        and workable.action==action.action or false
end

function M.Install(player)
    if states[player] then return end
    local controller=assert(player.components.playercontroller,"native player controller unavailable")
    local state={enabled=controller.enabled~=false,projected=false,input_seq=0,serial=0,pending={},idle={}}
    states[player]=state
    local enable=controller.Enable
    state.enable=function(value) return enable(controller,value) end
    function controller:Enable(value)
        state.enabled=value and true or false
        return enable(self,not state.projected and value)
    end
end

function M.Projected(player,projected)
    M.Install(player)
    local state=states[player]
    state.projected=projected
    state.enable(not projected and state.enabled)
end

local function Flags(player,state)
    local sg=player.sg
    local busy=sg and sg:HasStateTag("busy") or false
    local attack=sg and sg:HasStateTag("attack") or false
    return busy,state.enabled and not busy and not attack,state.enabled and not busy
end

local function Active(player,state)
    if not state.tracking then return false end
    local sg=player.sg
    if player:GetBufferedAction() or not state.enabled
        or sg and not sg:HasStateTag("idle") and not sg:HasStateTag("moving") then return true end
    state.tracking=false
    local waiting=state.idle;state.idle={}
    for _,fn in ipairs(waiting) do fn() end
    return false
end

function M.WhenIdle(player,fn)
    local state=states[player]
    if state and Active(player,state) then table.insert(state.idle,fn) else fn() end
end

function M.CanAct(player)
    local state=states[player]
    if not state then return true end
    local busy,can_move,can_act=Flags(player,state)
    return can_act
end

function M.Execute(action,completed)
    local player=action.doer
    M.Install(player)
    local state=states[player]
    local marked=false
    local function finish(success)
        if marked then return end
        marked=true;state.pending[action]=nil
        -- Succeed/Fail run inside BufferedAction:Do; its caller must finish capturing the native result first.
        player:DoTaskInTime(0,function() completed(success) end)
    end
    local busy,can_move,can_act=Flags(player,state)
    if not can_act then finish(false);return false end
    action:AddSuccessAction(function() finish(true) end)
    action:AddFailAction(function() finish(false) end)
    -- Each accepted resource click uses the original action once; long activities retain the native SG.
    if M.IsImmediate(action) then
        local impact
        if action.action.id=="MINE" and action.target and action.target.Transform then
            impact={action.target.Transform:GetWorldPosition()}
        end
        local ok,success=pcall(action.Do,action)
        if not ok then finish(false);error(success) end
        if success and impact then
            -- The native mining impact belonged to its SG timeline; only its visuals/sound are adapted here.
            local fx=SpawnPrefab("mining_fx")
            if fx then fx.Transform:SetPosition(impact[1],impact[2],impact[3]) end
            player.SoundEmitter:PlaySound("dontstarve/wilson/use_pick_rock")
        end
        if not marked then finish(success) end
        return success
    end
    state.pending[action]=finish
    if not state.tracking then
        state.serial=state.serial+1
        state.token=tostring(player.GUID).."-"..tostring(state.serial)
        state.input_seq=0;state.tracking=true
    end
    local ok,err=pcall(player.PushBufferedAction,player,action)
    if not ok then finish(false);error(err) end
    if not marked and player:GetBufferedAction()~=action then finish(false) end
    return true
end

function M.Sync(player,pose)
    M.Projected(player,true)
    local state=states[player]
    if state.session~=pose.session then state.session=pose.session;state.input_seq=0 end
    for action,finish in pairs(state.pending) do
        if player:GetBufferedAction()~=action then finish(false) end
    end
    local active=Active(player,state)
    local input=pose.activity
    if active and type(input)=="table" and input.token==state.token and type(input.seq)=="number"
        and input.seq>state.input_seq and input.seq==math.floor(input.seq) and input.seq<=9007199254740991
        and type(input.move)=="boolean" and type(input.cancel)=="boolean" then
        state.input_seq=input.seq
        local busy,can_move=Flags(player,state)
        if can_move and (input.move or input.cancel) then
            -- Same primitive used by the native controller: SG handles locomote and components clean themselves up.
            player:InterruptBufferedAction()
            player.components.locomotor:RunInDirection((pose.yaw or 0)+90)
        end
    end
    return active
end

function M.Snapshot(player)
    player=player or GetPlayer()
    local state=states[player]
    if not state then return {token="",active=false,state="",busy=false,controls=true,can_move=true,input_seq=0} end
    local active=Active(player,state)
    local busy,can_move=Flags(player,state)
    return {token=state.token or "",active=active,state=player.sg and player.sg.currentstate.name or "",
        busy=busy,controls=state.enabled,can_move=can_move,input_seq=state.input_seq}
end

return M
