-- MC 方块 -> 饥荒（与 mcmod 的 McBlockExport 配对，读 devio/mc_blocks.txt）
--   w x z         MC 贴地的实心方块：饥荒放一个看不见的障碍物并登记为寻路墙，饥荒的怪走不过去、会绕路
--   l x y z 亮度  MC 发光方块：饥荒放一个光源照亮地面，站在光里查理就不会来
-- 坐标是 MC 方块坐标。MC 不在驱动时全部撤掉（MC 的世界那时不在了）。

local mcbridge = require("starvecraft/mcbridge")
local link = require("starvecraft/link")

local M = {}

local FILE = STARVECRAFT.MODROOT .. "devio/mc_blocks.txt"
-- MC 亮度（最高 15）-> 饥荒光照半径：火把 14 级 ≈ 2.8，和饥荒手里的火把差不多亮
local LIGHT_RADIUS_PER_LEVEL = .2

local walls = {}  -- "x z" -> 障碍
local lights = {} -- 整行 -> 光源
local applied_seq = nil

local function ReadBlocks()
    local f = io.open(FILE, "r")
    if not f then
        return nil
    end
    local s = f:read("*a")
    f:close()
    -- 首行 "seq N"、末行 "end N"，不一致说明读到了半写的文件
    local seq = s:match("^seq (%d+)")
    if not seq or s:match("end (%d+)%s*$") ~= seq then
        return nil
    end
    if s:match("\nsession (%S+)\n") ~= link.PairId() .. ":" .. link.McSession() .. ":" .. link.session then return nil end
    return seq, s
end

local function BlockCenter(bx, bz)
    local x, _, z = mcbridge.ToDS(bx + .5, 0, bz + .5)
    return x, z
end

local function SpawnWall(bx, bz)
    local x, z = BlockCenter(bx, bz)
    local inst = CreateEntity()
    inst.entity:AddTransform()
    inst:AddTag("mc_block")
    inst:AddTag("NOCLICK")
    inst.persists = false
    -- 和饥荒自己的墙一样：半径 0.5 的障碍物，相邻两格之间不留缝
    MakeObstaclePhysics(inst, .5)
    inst.Physics:Teleport(x, 0, z)
    GetWorld().Pathfinder:AddWall(x, 0, z)
    return inst
end

local function RemoveWall(inst)
    local x, y, z = inst.Transform:GetWorldPosition()
    GetWorld().Pathfinder:RemoveWall(x, y, z)
    inst:Remove()
end

local function SpawnLight(bx, bz, level)
    local x, z = BlockCenter(bx, bz)
    local inst = CreateEntity()
    inst.entity:AddTransform()
    inst.entity:AddLight()
    inst:AddTag("mc_block")
    inst:AddTag("NOCLICK")
    inst:AddTag("FX")
    inst.persists = false
    -- 饥荒的光照在地面上算，光源一律放在地面（插在柱子上的火把也照它脚下）
    inst.Transform:SetPosition(x, 0, z)
    inst.Light:Enable(true)
    inst.Light:SetRadius(level * LIGHT_RADIUS_PER_LEVEL)
    inst.Light:SetIntensity(.75)
    inst.Light:SetFalloff(.5)
    inst.Light:SetColour(197 / 255, 197 / 255, 50 / 255)
    return inst
end

local function Apply(text)
    local want_walls, want_lights = {}, {}
    for line in text:gmatch("[^\n]+") do
        local x, z = line:match("^w (%-?%d+) (%-?%d+)$")
        if x then
            want_walls[x .. " " .. z] = { tonumber(x), tonumber(z) }
        end
        local lx, _, lz, level = line:match("^l (%-?%d+) (%-?%d+) (%-?%d+) (%d+)$")
        if lx then
            want_lights[line] = { tonumber(lx), tonumber(lz), tonumber(level) }
        end
    end
    for key, inst in pairs(walls) do
        if not want_walls[key] then
            RemoveWall(inst)
            walls[key] = nil
        end
    end
    for key, b in pairs(want_walls) do
        if not walls[key] then
            walls[key] = SpawnWall(b[1], b[2])
        end
    end
    for key, inst in pairs(lights) do
        if not want_lights[key] then
            inst:Remove()
            lights[key] = nil
        end
    end
    for key, l in pairs(want_lights) do
        if not lights[key] then
            lights[key] = SpawnLight(l[1], l[2], l[3])
        end
    end
end

local function Clear()
    for _, inst in pairs(walls) do
        RemoveWall(inst)
    end
    for _, inst in pairs(lights) do
        inst:Remove()
    end
    walls, lights, applied_seq = {}, {}, nil
end

function M.Describe()
    local nw, nl = 0, 0
    for _ in pairs(walls) do
        nw = nw + 1
    end
    for _ in pairs(lights) do
        nl = nl + 1
    end
    return string.format("mc_walls=%d mc_lights=%d", nw, nl)
end

-- active()：MC 当前是否在驱动
function M.Install(player, active)
    player:DoPeriodicTask(.1, function()
        if not active() then
            if applied_seq then
                Clear()
            end
            return
        end
        local seq, text = ReadBlocks()
        if seq and seq ~= applied_seq then
            applied_seq = seq
            Apply(text)
        end
    end)
end

return M
