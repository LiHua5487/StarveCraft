-- 记录每个 AnimState 现在是什么样（饥荒只提供"是不是在播某个动画""播到百分之几"这类查询，
-- 没有"当前 bank/build/动画名"的接口；MC 要按原样画饥荒的生物就得知道这些）。
-- 做法：所有 AnimState 共用一张方法表，在里面包一层，记下 SetBank / SetBuild / PlayAnimation / PushAnimation /
-- OverrideSymbol 等调用；当前动画 = 记下的播放队列里 IsCurrentAnimation 为真的那一个。

local M = {}

-- AnimState -> { bank, build, queue = {{名字, 是否循环}...}, overrides = {符号 = {build, 符号}}, hidden = {符号 = true} }
local states = setmetatable({}, { __mode = "k" })
local icons = setmetatable({}, { __mode = "k" })

local function Track(anim)
    local s = states[anim]
    if not s then
        s = { queue = {}, overrides = {}, hidden = {}, generation = 0, revision = 0 }
        states[anim] = s
    end
    return s
end

function M.Install()
    local probe = CreateEntity()
    probe.entity:AddTransform()
    local anim = probe.entity:AddAnimState()
    local mt = getmetatable(anim)
    local api = mt and mt.__index
    probe:Remove()
    if type(api) ~= "table" or type(api.PlayAnimation) ~= "function" then
        M.error = string.format("no shared method table (anim=%s mt=%s index=%s)", type(anim), type(mt), type(api))
        return false
    end
    local function Wrap(name, record)
        local orig = api[name]
        if type(orig) ~= "function" then
            return
        end
        api[name] = function(self, ...)
            local state=Track(self);record(state,...);state.revision=state.revision+1
            return orig(self, ...)
        end
    end
    Wrap("SetBank", function(s, bank) s.bank = bank end)
    Wrap("SetMultColour", function(s, r, g, b, a) s.colour = {r, g, b, a} end)
    Wrap("SetBuild", function(s, build) s.build = build end)
    Wrap("SetOrientation", function(s, value) s.ground = value==ANIM_ORIENTATION.OnGround end)
    Wrap("SetLayer", function(s, value) s.layer = value end)
    Wrap("SetSortOrder", function(s, value) s.sort = value end)
    Wrap("PlayAnimation", function(s, name, loop) s.generation=s.generation+1;s.queue = { { name, loop and true or false, s.generation } } end)
    Wrap("SetPercent", function(s, name) s.generation=s.generation+1;s.queue = { { name, false, s.generation } } end)
    -- PushAnimation 不传 loop 时默认循环
    Wrap("PushAnimation", function(s, name, loop) s.generation=s.generation+1;table.insert(s.queue, { name, loop ~= false, s.generation }) end)
    Wrap("OverrideSymbol", function(s, symbol, build, from) s.overrides[symbol] = { build, from } end)
    Wrap("ClearOverrideSymbol", function(s, symbol) s.overrides[symbol] = nil end)
    Wrap("Hide", function(s, symbol) s.hidden[symbol] = true end)
    Wrap("Show", function(s, symbol) s.hidden[symbol] = nil end)
    local marker=CreateEntity()
    marker.entity:AddTransform()
    local mini=marker.entity:AddMiniMapEntity()
    local mini_api=getmetatable(mini).__index
    local set_icon=mini_api.SetIcon
    mini_api.SetIcon=function(self,icon,...) icons[self]=icon;return set_icon(self,icon,...) end
    marker:Remove()
    M.installed = true
    return true
end

function M.MapIcon(inst) return inst.MiniMapEntity and icons[inst.MiniMapEntity] or "" end

-- 当前状态：{ bank, build, anim, loop, percent, facing, overrides, hidden }；没记录到时为 nil
function M.Get(inst,result)
    local anim = inst.AnimState
    local s = anim and states[anim]
    if not s then
        return nil
    end
    -- 队列前面已经播完的丢掉
    for i, entry in ipairs(s.queue) do
        if anim:IsCurrentAnimation(entry[1]) then
            for _ = 1, i - 1 do
                table.remove(s.queue, 1)
            end
            local out=result or {}
            out.bank,out.build,out.anim,out.loop=s.bank,s.build,entry[1],entry[2]
            out.percent,out.facing,out.generation=anim:GetPercent(),anim:GetCurrentFacing(),entry[3]
            out.revision=s.revision
            out.overrides,out.hidden,out.colour=s.overrides,s.hidden,s.colour
            out.ground,out.layer,out.sort=s.ground,s.layer,s.sort
            return out
        end
    end
    return { bank = s.bank, build = s.build, anim = "?", queue = #s.queue }
end

function M.Describe(inst)
    local st = M.Get(inst)
    if not st then
        return "untracked"
    end
    local n = 0
    for _ in pairs(st.overrides or {}) do
        n = n + 1
    end
    return string.format("bank=%s build=%s anim=%s loop=%s pct=%.2f facing=%s overrides=%d",
        tostring(st.bank), tostring(st.build), tostring(st.anim), tostring(st.loop),
        st.percent or -1, tostring(st.facing), n)
end

return M
