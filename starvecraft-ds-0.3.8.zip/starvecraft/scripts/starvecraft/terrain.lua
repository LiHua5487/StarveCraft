-- Native tiles are cached as runs; rendering and collision consume the same map.
local M={}
local cache=setmetatable({}, {__mode="k"})
local hooked=false
function M.Export()
    local map=GetWorld().Map
    if not hooked then
        local api=getmetatable(map).__index
        local set=api.SetTile
        api.SetTile=function(self,...) local result=set(self,...);cache[self]=nil;return result end
        hooked=true
    end
    local data=cache[map]
    if not data then
        local width,height=map:GetSize()
        assert(width>0 and height>0 and width*height<=1048576,"invalid native terrain size")
        local rows,palette={},{}
        for z=height-1,0,-1 do
            local runs,last,count={},nil,0
            local function flush() if last then table.insert(runs,last..":"..count) end end
            for x=0,width-1 do
                local id=map:GetTile(x,z)
                local info=GetTileInfo(id)
                if id==GROUND.IMPASSABLE or id==GROUND.INVALID or not info then id=0
                else palette[tostring(id)]={material=info.name,noise=info.noise_texture} end
                if id==last then count=count+1 else flush();last,count=id,1 end
            end
            flush();table.insert(rows,table.concat(runs,","))
        end
        local first_x,first_y,first_z=map:GetTileCenterPoint(-width*2,0,-height*2)
        data={width=width,height=height,rows=table.concat(rows,";"),palette=palette,
            left=first_x-2,far_z=first_z+(height-1)*4+2}
        cache[map]=data
    end
    local origin=require("starvecraft/mcbridge").origin
    local x,z=data.left-origin.x,origin.z-data.far_z
    if not data.view or data.view.x~=x or data.view.z~=z then
        data.view={width=data.width,height=data.height,rows=data.rows,palette=data.palette,x=x,z=z}
    end
    return data.view
end
return M
