-- Native builder executes crafts. MC sends an escrow receipt, never a second recipe table.
local M={}
local json=require("json")
local items=require("starvecraft/items")
local link=require("starvecraft/link")
local channel=require("starvecraft/channel")
local bridge=require("starvecraft/mcbridge")
local cached, next_catalog, sequence=nil, 0, 0
local function Allowed(builder,recipe)
    return builder:KnowsRecipe(recipe.name) or CanPrototypeRecipe(recipe.level,builder.accessible_tech_trees)
end
function M.Export()
    if GetTime()<next_catalog then return end
    next_catalog=GetTime()+.5
    local builder=GetPlayer().components.builder
    builder:EvaluateTechTrees()
    local ui=GetPlayer().HUD and GetPlayer().HUD.controls and GetPlayer().HUD.controls.crafttabs
    if not ui then return end
    local tabs={}
    for index,tab in ipairs(ui.tab_order) do
        tabs[tab.filter]={slot=index-1,id=tab.filter.str,name=tab.tabname,
            atlas=items.Path(tab.icon_atlas),image=tab.icon}
    end
    local recipes={}
    for name,r in pairs(GetAllRecipes()) do
        if not r.is_deconstruction_recipe and tabs[r.tab] then
            local ingredients={}
            for _,ing in ipairs(r.ingredients) do
                local item=items.Spec(ing.type)
                item.count=math.max(1,RoundUp(ing.amount*builder.ingredientmod))
                table.insert(ingredients,item)
            end
            local out=items.Spec(r.product,r)
            if r.placer then out.max_stack=1
            else
                local native=items.Equivalent(r.product)
                native.name=out.name;native.atlas=out.atlas;native.image=out.image
                out=native
            end
            out.count=r.numtogive
            local known=builder:KnowsRecipe(name)
            table.insert(recipes,{name=name,tab=tabs[r.tab],ingredients=ingredients,output=out,structure=r.placer~=nil,
                show=known or ShouldHintRecipe(r.level,builder.accessible_tech_trees),
                allowed=Allowed(builder,r) and not (r.placer and builder:IsBuildBuffered(name))})
        end
    end
    for _,recipe in ipairs(require("starvecraft/conversion").Recipes()) do table.insert(recipes,recipe) end
    table.sort(recipes,function(a,b) return a.name<b.name end)
    sequence=sequence+1
    local body={pair=link.PairId(),session=link.session,seq=sequence,recipes=recipes}
    channel.Write("ds_crafting.json","seq "..sequence.."\n"..json.encode(body).."\nend "..sequence.."\n")
end
function M.HookBuilder(builder)
    local save,load=builder.OnSave,builder.OnLoad
    -- shortcut: Retain completed receipts for replay safety; prune only after durable MC acknowledgements exist.
    builder.sc_receipts={}
    builder.sc_item_states={}
    function builder:OnSave()
        for _,entry in pairs(require("starvecraft/equipment").live) do require("starvecraft/equipment").Remember(entry.item,entry.id) end
        local data=save(self) or {}
        data.starvecraft_receipts=self.sc_receipts
        data.starvecraft_item_states=self.sc_item_states
        return data
    end
    function builder:OnLoad(data)
        load(self,data)
        self.sc_receipts=data.starvecraft_receipts or {}
        self.sc_item_states=data.starvecraft_item_states or {}
    end
end
function M.Capture(item)
    if not M.outputs then return false end
    require("starvecraft/inventory").Track(item)
    table.insert(M.outputs,item)
    return true
end
function M.Projecting() return M.projecting end
local function Reply(result)
    channel.Send("craft_result "..json.encode(result))
end
function M.Execute(request)
    if type(request)~="table" or type(request.id)~="string" or not request.id:match("^[%w%-]+$") or #request.id>64 then return end
    local player=GetPlayer()
    local builder=player.components.builder
    local receipts=builder.sc_receipts
    if receipts[request.id] then Reply(receipts[request.id]); return end
    local recipe=type(request.recipe)=="string" and GetRecipe(request.recipe)
    local result={id=request.id,recipe=request.recipe,ok=false,outputs={}}
    local store=require("starvecraft/inventory")
    local equipment=require("starvecraft/equipment")
    local invasion=require("starvecraft/invasion")
    if require("starvecraft/conversion").Execute(request,result) then
        receipts[request.id]=result;Reply(result);return
    end
    if recipe then
        if request.deploy then
            local x,z=tonumber(request.x),tonumber(request.z)
            local receipt=type(request.receipt)=="string" and receipts[request.receipt]
            local reservation=receipt and receipt.outputs and receipt.outputs[1] and receipt.outputs[1].buffered_build
            if recipe.placer and receipt and receipt.ok and receipt.recipe==recipe.name and reservation~=nil and not receipt.placed
                and x and z and math.abs(x)<1000000 and math.abs(z)<1000000 then
                local dx,_,dz=bridge.ToDS(x,0,z)
                local pt=Point(dx,0,dz)
                if player:GetDistanceSqToPoint(pt)<25
                    and builder:CanBuildAtPoint(pt,recipe) then
                    local spec=request.item or receipt.outputs[1]
                    spec.import_id=spec.import_id or request.id
                    local claim=equipment.Acquire(spec)
                    if not claim or not claim.sc_mc_item or claim.sc_mc_item.structure_recipe~=recipe.name then
                        if claim then store.Keep(claim) end
                        receipts[request.id]=result;Reply(result);return
                    end
                    local previous=builder.buffered_builds[recipe.name]
                    builder.buffered_builds[recipe.name]=deepcopy(reservation)
                    invasion.BeginEffects()
                    local ok,built=pcall(builder.DoBuild,builder,recipe.name,pt,tonumber(request.rotation) or 0)
                    local effects=invasion.EndEffects();if next(effects) then result.effects=effects end
                    builder.buffered_builds[recipe.name]=previous
                    result.ok=ok and built and true or false
                    if result.ok then receipt.placed=true;claim:Remove()
                    else store.Keep(claim) end
                    if not ok then receipts[request.id]=result;Reply(result);error(built) end
                end
            end
        elseif Allowed(builder,recipe) and not (recipe.placer and builder:IsBuildBuffered(recipe.name)) then
            local projected={}
            local inventory=player.components.inventory
            local slots,active,overflow,containers=inventory.itemslots,inventory.activeitem,inventory.overflow,inventory.opencontainers
            -- The native builder must see exactly the MC grid, not nearby native inventories.
            inventory.itemslots={};inventory.activeitem=nil;inventory.overflow=nil;inventory.opencontainers={}
            M.outputs={}
            invasion.BeginEffects()
            local ok,err=pcall(function()
                assert(type(request.inputs)=="table" and #request.inputs==#recipe.ingredients,"missing actual crafting inputs")
                M.projecting=true
                for index,ing in ipairs(recipe.ingredients) do
                    local count=math.max(1,RoundUp(ing.amount*builder.ingredientmod))
                    local spec=request.inputs[index]
                    assert(type(spec)=="table" and spec.prefab==ing.type and spec.count==count,"crafting input mismatch")
                    spec.import_id=spec.import_id or request.id.."-"..index
                    local item=equipment.Acquire(spec)
                    assert(item,"crafting input reference is unavailable")
                    table.insert(projected,item)
                    assert(item.prefab==ing.type,"crafting input reference changed")
                    equipment.Detach(item)
                    inventory:GiveItem(item,index,nil,true)
                end
                M.projecting=false
                if not builder:CanBuild(recipe.name) then return end
                if recipe.placer then
                    builder:BufferBuild(recipe.name)
                    local reservation=deepcopy(builder.buffered_builds[recipe.name])
                    -- The reserved build now belongs to the MC item, not a second backend inventory.
                    builder.buffered_builds[recipe.name]=nil
                    local item=items.Spec(recipe.product,recipe)
                    item.mc=nil;item.max_stack=1;item.structure_recipe=recipe.name
                    item.craft_receipt=request.id
                    item.buffered_build=reservation
                    local claim=SpawnPrefab("blueprint")
                    items.Parcel(claim,item)
                    table.insert(result.outputs,store.Keep(claim))
                    result.ok=true
                else
                    result.ok=builder:DoBuild(recipe.name) and true or false
                end
                if result.ok and not builder:KnowsRecipe(recipe.name) then builder:UnlockRecipe(recipe.name) end
            end)
            inventory.itemslots=slots;inventory.activeitem=active;inventory.overflow=overflow;inventory.opencontainers=containers
            local effects=invasion.EndEffects();if next(effects) then result.effects=effects end
            M.projecting=false
            local remaining={}
            for _,item in ipairs(projected) do
                if item:IsValid() then table.insert(remaining,store.Keep(item)) end
            end
            if result.ok then
                for _,spec in ipairs(remaining) do table.insert(result.outputs,spec) end
            else result.refunds=remaining;result.refund_from=#projected+1 end
            for _,item in ipairs(M.outputs) do
                if item:IsValid() then table.insert(result.outputs,store.Keep(item)) end
            end
            M.outputs=nil
            if not ok then receipts[request.id]=result;Reply(result);error(err) end
        end
    end
    receipts[request.id]=result
    next_catalog=0
    Reply(result)
end
return M
