local M = {}
local DEVIO = STARVECRAFT.MODROOT .. "devio/"
local function ReadFile(name)
    local f = io.open(DEVIO .. name, "r")
    if not f then
        return nil
    end
    local s = f:read("*a")
    f:close()
    return s
end

local function WriteFile(name, text)
    local f, err = io.open(DEVIO .. name, "w")
    if not f then error("StarveCraft cannot write " .. name .. ": " .. tostring(err)) end
    local written, write_err = f:write(text)
    local closed, close_err = f:close()
    if not written or not closed then error("StarveCraft write failed: " .. tostring(write_err or close_err)) end
end

local function Context() local link = require("starvecraft/link"); return link.PairId() .. ":" .. link.McSession() .. ":" .. link.session end
local out_session = ""
local out_seq = 0
local out_recent = {}

function M.Send(payload)
    local session = Context()
    if session ~= out_session then out_session, out_seq, out_recent = session, 0, {} end
    out_seq = out_seq + 1
    table.insert(out_recent, out_seq .. " " .. payload .. " ;")
    if #out_recent > 128 then
        table.remove(out_recent, 1)
    end
    WriteFile("ds_events.txt", "session " .. out_session .. "\n" .. table.concat(out_recent, "\n") .. "\n")
end

local in_session, in_last = nil, 0

function M.Poll(handler)
    local s = ReadFile("mc_events.txt")
    if not s then
        return
    end
    local session = s:match("^session (%S+)")
    if not session or session ~= Context() then
        return
    end
    if session ~= in_session then
        in_session, in_last = session, 0
    end
    for line in s:gmatch("[^\n]+") do
        local seq, payload = line:match("^(%d+) (.-) ;%s*$")
        seq = tonumber(seq)
        if seq and seq > in_last then
            if handler(payload) == false then break end
            in_last = seq
        end
    end
end


M.Read = ReadFile
M.Write = WriteFile
M.Context = Context
return M
