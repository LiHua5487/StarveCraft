local M={}
local overlays=setmetatable({},{__mode="k"})
local hooked=false
function M.HookSeason(manager)
    local map=manager.inst.Map
    if not map or hooked then return end
    hooked=true
    local api=getmetatable(map).__index
    for _,method in ipairs({"SetOverlayTexture","SetOverlayLerp","SetOverlayColor0","SetOverlayColor1","SetOverlayColor2"}) do
        local original=api[method]
        if original then api[method]=function(self,...)
            local state=overlays[self] or {};overlays[self]=state
            state[method]={...}
            return original(self,...)
        end end
    end
end
function M.Snapshot()
    local world=GetWorld()
    local season=world.components.seasonmanager
    if not season then return {kind="clear",rate=0,snow=0,season="",temperature=0,light=1} end
    return {kind=season.precip and season.preciptype or "clear",
        rate=season.precip and math.max(0,math.min(1,season:GetPrecipitationRate())) or 0,
        snow=season:GetSnowPercent(),season=season:GetSeasonString(),
        temperature=season:GetCurrentTemperature(),light=season:GetWeatherLightPercent(),
        overlay=overlays[world.Map]}
end
return M
