-- A projection of the MC player, not a second survival character.
local bridge = require("starvecraft/mcbridge")
local link = require("starvecraft/link")
local channel = require("starvecraft/channel")
local compat = require("starvecraft/compat")
local json = require("json")
local M = {}
local effect_depth, effects = 0, nil
function M.IsActive() return link.Active() end

local function RecordEffect(kind, amount, cause)
    if amount == 0 then return end
    if effects then
        effects[kind] = (effects[kind] or 0) + amount
        if kind=="health" and amount<0 and cause then effects.cause=tostring(cause):sub(1,64) end
    elseif link.Active() and bridge.pose then
        local result = {seq=bridge.pose.seq,time=GetTime(),cause=tostring(cause or "native"):sub(1,64)}
        result[kind] = amount
        channel.Send("player_effect " .. json.encode(result))
    end
end

function M.BeginEffects()
    if effect_depth == 0 then effects = {} end
    effect_depth = effect_depth + 1
end

function M.EndEffects()
    assert(effect_depth > 0, "native effects scope is not open")
    effect_depth = effect_depth - 1
    if effect_depth > 0 then return {} end
    local result = effects
    effects = nil
    return result
end

function M.Armor(request)
    if type(request)~="table" or type(request.id)~="string" or not request.id:match("^[%w%-]+$")
        or #request.id>64 or type(request.amount)~="number" or request.amount~=request.amount or request.amount<=0 or request.amount>1000 then return end
    local player=GetPlayer()
    local receipts=player.components.builder.sc_receipts
    local function reply(result) channel.Send("armor_result "..json.encode(result)) end
    if receipts[request.id] then reply(receipts[request.id]);return end
    if not M.Sync() then return end
    local result={id=request.id,ok=false,amount=request.amount,equipment={}}
    local equipment=require("starvecraft/equipment")
    local worn=equipment.ArmorEquipment(request.equipment)
    if not worn then receipts[request.id]=result;reply(result);return end
    local inventory=player.components.inventory
    local current=inventory.equipslots
    inventory.equipslots=worn
    M.BeginEffects()
    local ok,remaining=pcall(inventory.ApplyDamage,inventory,compat.ToDS(request.amount))
    for slot,item in pairs(current) do if not item:IsValid() then current[slot]=nil end end
    inventory.equipslots=current
    local captured=M.EndEffects();if next(captured) then result.effects=captured end
    if ok and type(remaining)=="number" and remaining==remaining and remaining>=0 and remaining<=compat.ToDS(request.amount) then
        result.ok=true;result.amount=compat.ToMC(remaining)
    elseif ok then ok=false;remaining="invalid native armour result" end
    for _,item in pairs(worn) do
        table.insert(result.equipment,equipment.Remember(item,item.sc_item_id))
    end
    receipts[request.id]=result;reply(result)
    if not ok then error(remaining) end
end

function M.Sync()
    if not link.Paired() then return false end
    link.RefreshPlayer()
    if not link.Active() then return false end
    local player, p = GetPlayer(), bridge.pose
    local activity=require("starvecraft/activity")
    activity.Projected(player,true)
    local acting=activity.Sync(player,p)
    local x, _, z = bridge.ToDS(p.x, p.y, p.z)
    if not acting then
        player:ClearBufferedAction()
        player.components.locomotor:Stop()
        player.Physics:Stop()
        player.Transform:SetRotation((p.yaw or 0) + 90)
    end
    if not require("starvecraft/travel").Waiting(p) then player.Physics:Teleport(x,0,z)
    else local nx,ny,nz=player.Transform:GetWorldPosition();x,z=nx,nz end
    require("starvecraft/surface").Update(player)
    -- Mirror MC health for native target checks; never run a second death here.
    player.components.health.maxhealth = compat.ToDS(p.max_health)
    player.components.health.currenthealth = math.max(1, compat.ToDS(p.health))
    local hunger = player.components.hunger
    if hunger and p.food ~= nil then hunger.current = compat.HungerToDS(p.food,hunger.max) end
    if M.exposure then
        M.exposure.Transform:SetPosition(x, 0, z)
        M.exposure.Light:Enable((p.block_light or 0) > 0)
    end
    local targetable = p.targetable ~= false
    if M.life_session ~= p.session or M.targetable ~= targetable then
        M.life_session, M.targetable = p.session, targetable
        player:PushEvent("invincibletoggle", {invincible=not targetable})
    end
    return true
end

-- Refresh the projection before the native attack tests distance. No new range rules.
function M.HookCombat(combat)
    local attack = combat.DoAttack
    function combat:DoAttack(target, weapon, projectile, ...)
        if link.Paired() and self.inst == GetPlayer() and not M.native_action and not projectile then return end
        if link.Paired() and (target or self.target) == GetPlayer() and not M.Sync() then return end
        if link.Paired() and (target or self.target) == GetPlayer() and bridge.pose.blocked_attackers
            and bridge.pose.blocked_attackers[tostring(self.inst.GUID)] then return end
        return attack(self, target, weapon, projectile, ...)
    end
end

function M.Install(player)
    local activity=require("starvecraft/activity")
    activity.Install(player)
    local health = player.components.health
    local attacked, delta, isdead, invincible = player.components.combat.GetAttacked, health.DoDelta, health.IsDead, health.IsInvincible
    local hunger, sanity, temperature, moisture = player.components.hunger, player.components.sanity, player.components.temperature, player.components.moisture
    local hunger_delta = hunger.DoDelta
    function hunger:DoDelta(...)
        if not link.Paired() then return hunger_delta(self, ...) end
        local old = self.current
        local result = hunger_delta(self, ...)
        RecordEffect("hunger",compat.HungerToMC(self.current-old,self.max),"food")
        return result
    end
    local sanity_delta = sanity and sanity.DoDelta
    if sanity then
        function sanity:DoDelta(amount,...)
            if not link.Paired() then return sanity_delta(self,amount,...) end
            RecordEffect("sanity",amount,"native")
        end
    end
    -- Project MC's measured light at the player; do not reproduce its light propagation in DS.
    local exposure = CreateEntity()
    exposure.entity:AddTransform()
    exposure.entity:AddLight()
    exposure:AddTag("FX")
    exposure:AddTag("NOCLICK")
    exposure.persists = false
    exposure.Light:SetRadius(1)
    exposure.Light:SetIntensity(.8)
    exposure.Light:SetFalloff(.5)
    exposure.Light:SetColour(1, 1, 1)
    exposure.Light:Enable(false)
    M.exposure = exposure
    local pending
    local original = {max=health.maxhealth, health=health.currenthealth,
        hunger=hunger.hungerrate,hunger_current=hunger.current,hunger_burning=hunger.burning, invincible=health.invincible,
        sanity=sanity and sanity.current, sane=sanity and sanity.sane,moisture=moisture and moisture:GetMoisture()}
    if moisture then
        local shelter=moisture.CheckForShelter
        function moisture:CheckForShelter() if not link.Paired() then return shelter(self) end end
    end

    function health:IsDead()
        if link.Paired() then return bridge.pose ~= nil and bridge.pose.dead end
        return isdead(self)
    end
    function health:IsInvincible()
        if link.Paired() then return invincible(self) or bridge.pose ~= nil and bridge.pose.targetable == false end
        return invincible(self)
    end
    function health:DoDelta(amount, overtime, cause, ...)
        if not link.Paired() then return delta(self, amount, overtime, cause, ...) end
        if cause == "cold" or cause == "hot" then return end
        if pending and amount < 0 then pending.damage = (pending.damage or 0)-amount
        else RecordEffect("health",compat.ToMC(amount),cause) end
    end
    local combat = player.components.combat
    local can_be_attacked = combat.canbeattackedfn
    combat.canbeattackedfn = function(inst, attacker)
        if link.Paired() and (not link.Active() or bridge.pose.targetable == false) then return false end
        return not can_be_attacked or can_be_attacked(inst, attacker)
    end
    function combat:GetAttacked(attacker, damage, weapon, ...)
        if not link.Paired() then return attacked(self, attacker, damage, weapon, ...) end
        if not M.Sync() or not damage or damage <= 0 then return false end
        if attacker and bridge.pose.blocked_attackers and bridge.pose.blocked_attackers[tostring(attacker.GUID)] then return false end
        local outer = pending
        local hit = {seq=bridge.pose.seq}
        pending = hit
        -- Keep native attacked/onhitother callbacks; only health ownership changes.
        local ok, result = pcall(attacked, self, attacker, damage, weapon, ...)
        pending = outer
        if not ok then error(result) end
        if result and hit.damage then
            local x, z = bridge.pose.x, bridge.pose.z
            if attacker then
                local ax, ay, az = attacker.Transform:GetWorldPosition()
                local mx, _, mz = bridge.ToMC(ax, ay, az)
                x, z = mx, mz
            end
            channel.Send(string.format("hit %.3f %s %s %.3f %.3f %d %.3f",
                compat.ToMC(hit.damage), attacker and attacker.GUID or 0,
                attacker and attacker.prefab or "charlie", x, z, hit.seq, GetTime()))
        end
        return result
    end

    local projected = false
    player:DoPeriodicTask(.05, function()
        local paired = link.Paired()
        if paired ~= projected then
            projected = paired
            player.AnimState:SetMultColour(1, 1, 1, paired and 0 or 1)
            if player.DynamicShadow then player.DynamicShadow:Enable(not paired) end
            if player.HUD then if paired then player.HUD:Hide() else player.HUD:Show() end end
            activity.Projected(player,paired)
            if paired then
                health.invincible = false
                hunger:SetRate(0)
                hunger:Pause()
                if sanity then
                    sanity.current, sanity.sane = sanity.max, true
                    player:StopUpdatingComponent(sanity)
                end
                if temperature then player:StopUpdatingComponent(temperature) end
                if moisture then moisture:SetMoistureLevel(0);player:StopUpdatingComponent(moisture) end
                -- MC resolves body collisions; native pushes must not move its target proxy.
                player.Physics:ClearCollisionMask()
                local ground = rawget(_G, "GetWorldCollision")
                player.Physics:CollidesWith(ground and ground() or COLLISION.WORLD)
            else
                exposure.Light:Enable(false)
                if sanity then
                    sanity.current, sanity.sane = original.sanity, original.sane
                    player:StartUpdatingComponent(sanity)
                end
                if temperature then player:StartUpdatingComponent(temperature) end
                if moisture then moisture:SetMoistureLevel(original.moisture);player:StartUpdatingComponent(moisture) end
                health.maxhealth, health.currenthealth, health.invincible = original.max, original.health, original.invincible
                hunger:SetRate(original.hunger)
                hunger.current = original.hunger_current
                hunger.burning = original.hunger_burning
                MakeCharacterPhysics(player, 75, .5)
            end
        end
        if paired then
            M.Sync()
        end
    end)
end
return M
