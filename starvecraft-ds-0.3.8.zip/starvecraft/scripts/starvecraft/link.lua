-- 两边存档的握手（与 mcmod 的 Link 配对）：各写各的状态文件、读对方的，两边都进了配对的存档才开始入侵。
--   ds_link.txt  "阶段 配对编号 槽位 心跳 说明"   menu 主菜单 / loading 载入中 / newgame 在新游戏界面 / asking 在问要不要入侵 /
--                                               waiting 在配对存档里暂停等 MC / in 入侵中 / solo 只玩饥荒 / error 出错（说明里是原因）
--   mc_link.txt  "阶段 配对编号 饥荒槽位 心跳"    idle 不在入侵世界 / want 在入侵世界里等饥荒 / in 入侵进行中
-- 配对信息存在饥荒自己的存档索引里：每个槽位的 starvecraft 字段 = { id = 配对编号, origins = { 世界 = {x, z} } } 或 { declined = true }，
-- 在饥荒里删掉槽位时一起没了。
-- MC selects a world; the backend loads its pair or creates a native world in a free private slot.
-- Standalone DS retains its own save namespace. Managed worlds wait for their MC counterpart.
-- 状态在前端的每帧更新里处理（游戏暂停时也会跑）；载入新存档会重启整个 Lua 环境，要跨过去的信息写在 pending_pair.txt 里。

local mcbridge = require("starvecraft/mcbridge")

local M = { session = tostring(os.time()) .. tostring(math.random(100000, 999999)) }

local DEVIO = STARVECRAFT.MODROOT .. "devio/"
local POLL_MS = 50
-- MC 的心跳这么久没变就当它不在了
local MC_STALE_MS = 4000

local T = {
    wait_title = "等待 Minecraft",
    wait_text = "在装了 StarveCraft 的 Minecraft 单人游戏菜单中，选择与此存档配对的入侵世界。",
    lost_title = "Minecraft 离开了",
    lost_text = "Minecraft 退出了这个世界。重新进入配对的世界就能继续入侵。",
    solo = "只玩饥荒",
    save_quit = "保存并退出",
}

local state = { phase = "menu", id = "-", slot = -1, detail = "" }
local beat, last_beat_time, last_poll = 0, 0, 0
-- MC 的状态；alive 要求心跳在饥荒启动后变过（启动前留下的旧文件不算）
local mc = { phase = "idle", id = "-", slot = -1, beat = nil, changed = nil }
local handled = {}
local world = nil -- 进入存档后：{ slot = 槽位, id = 配对编号或 nil, solo = 是否只玩饥荒 }
local dialog = nil

-- ------------------------------------------------------------ 文件

local function ReadFile(name)
    local f = io.open(DEVIO .. name, "r")
    if not f then
        return nil
    end
    local s = f:read("*a")
    f:close()
    return s
end

local function WriteFile(name, text)
    local f = io.open(DEVIO .. name, "w")
    if f then
        f:write(text)
        f:close()
    end
end

local function SetState(phase, id, slot, detail)
    state.phase, state.id, state.slot, state.detail = phase, id or "-", slot or -1, detail or ""
    WriteFile("ds_link.txt", string.format("%s %s %d %d %s %s\n", state.phase, state.id, state.slot, beat, M.session, (STARVECRAFT.DEV and "isolated_unified_" or "") .. state.detail))
end

local function ReadMC()
    local s = ReadFile("mc_link.txt")
    local phase, id, slot, b, session, mode = (s or ""):match("^(%S+) (%S+) (%-?%d+) (%d+) (%S+) (%S+)\n")
    if not phase then
        return
    end
    if (mc.beat ~= b or mc.session ~= session) and math.abs(os.time() * 2 - tonumber(b)) < 12 then
        mc.changed = GetTimeReal()
    end
    mc.beat, mc.phase, mc.id, mc.slot, mc.session, mc.mode = b, phase, id, tonumber(slot), session, mode
end

local function McAlive()
    return mc.changed ~= nil and GetTimeReal() - mc.changed < MC_STALE_MS
end

local function McWants(id)
    return McAlive() and mc.phase == "want" and (id == nil or mc.id == id)
end

-- ------------------------------------------------------------ 存档索引里的配对信息

local function SlotInfo(slot)
    local s = SaveGameIndex.data.slots[slot]
    return s and s.starvecraft
end

local function SetSlotInfo(slot, info)
    SaveGameIndex.data.slots[slot].starvecraft = info
    SaveGameIndex:Save(function() end)
end

local function FindSlot(id)
    for i = 1, #SaveGameIndex.data.slots do
        local info = SlotInfo(i)
        if info and info.id == id then
            return i
        end
    end
end

local function FirstEmptySlot()
    for i = 1, #SaveGameIndex.data.slots do
        if SaveGameIndex:GetCurrentMode(i) == nil then
            return i
        end
    end
end

local function WritePending(id, slot)
    WriteFile("pending_pair.txt", string.format("%s %d %s\n", id, slot, mc.session))
end
local function TakePending()
    local id, slot, session = (ReadFile("pending_pair.txt") or ""):match("^(%S+) (%d+) (%S+)")
    WriteFile("pending_pair.txt", "")
    return id, tonumber(slot), session
end

-- ------------------------------------------------------------ 主菜单：响应 MC 的请求

local function LoadSlot(slot, id)
    WritePending(id, slot)
    local owned = SaveGameIndex:GetSlotDLC(slot) or {}
    for key, dlc in pairs({ REIGN_OF_GIANTS = REIGN_OF_GIANTS, CAPY_DLC = CAPY_DLC, PORKLAND_DLC = PORKLAND_DLC }) do
        if owned[key] then
            EnableDLC(dlc)
        else
            DisableDLC(dlc)
        end
    end
    SetState("loading", id, slot)
    TheFrontEnd:Fade(false, 1, function()
        StartNextInstance({ reset_action = RESET_ACTION.LOAD_SLOT, save_slot = slot, starvecraft_mode = STARVECRAFT.MODE })
    end)
end

-- Native world creation; the selected MC world gets its own free backend slot.
local function CreateSlot(slot, id)
    DisableAllDLC()
    EnableDLC(REIGN_OF_GIANTS)
    WritePending(id, slot)
    SetState("loading", id, slot)
    local dlc = { REIGN_OF_GIANTS = true, CAPY_DLC = false, PORKLAND_DLC = false }
    SaveGameIndex:StartSurvivalMode(slot, "wilson", { ROGEnabled = true }, function()
        StartNextInstance({ reset_action = RESET_ACTION.LOAD_SLOT, save_slot = slot, playeranim = "wakeup", starvecraft_mode = STARVECRAFT.MODE })
    end, dlc)
end

local function OnMenu()
    if state.phase == "loading" then return end
    local screen = TheFrontEnd:GetActiveScreen()
    local on_main = screen ~= nil and screen.name == "MainScreen"
    for _, candidate in ipairs(TheFrontEnd.screenstack or {}) do
        if candidate.name == "MainScreen" then on_main = true end
    end

    if not McWants() then
        handled = {}
        if state.phase == "error" then
            SetState("menu")
        end
    end
    if state.phase == "newgame" and on_main then
        -- 新游戏界面被关掉了（没开始）
        TakePending()
        SetState("error", state.id, state.slot, "newgame_cancelled")
    end
    if not on_main then
        SetState("menu", nil, nil, screen and screen.name or "none")
        return
    end
    if state.phase ~= "error" then
        SetState("menu", nil, nil, (screen and screen.name or "none") .. "_mc=" .. tostring(McAlive()) .. "_" .. tostring(mc.phase))
    end
    if not McWants() or handled[mc.id] then
        return
    end
    handled[mc.id] = true
    if (mc.mode == "test") ~= STARVECRAFT.DEV then SetState("error", mc.id, mc.slot, "mode_mismatch"); return end
    local slot = FindSlot(mc.id)
    if slot then
        LoadSlot(slot, mc.id)
        return
    end
    if mc.slot > 0 then
        -- MC 记着的槽位还有存档，但配对编号对不上：被覆盖过，别乱动
        SetState("error", mc.id, mc.slot, "slot_mismatch")
        return
    end
    local empty = FirstEmptySlot()
    if not empty then
        SetState("error", mc.id, -1, "no_free_slot")
        return
    end
    CreateSlot(empty, mc.id)
end

-- ------------------------------------------------------------ 进入存档后

local function CloseDialog()
    if dialog then
        TheFrontEnd:PopScreen(dialog)
        dialog = nil
        SetPause(false)
    end
end

local function ShowDialog(title, text, buttons)
    CloseDialog()
    local PopupDialogScreen = require("screens/popupdialog")
    dialog = PopupDialogScreen(title, text, buttons)
    TheFrontEnd:PushScreen(dialog)
    SetPause(true, "starvecraft")
end

local function PlaySolo()
    CloseDialog()
    world.solo = true
    SetState("solo", world.id or "-", world.slot)
end

local function SaveAndQuit()
    CloseDialog()
    EnableAllDLC()
    TheFrontEnd:Fade(false, 1, function()
        SaveGameIndex:SaveCurrent(function()
            inGamePlay = false
            GetPlayer():PushEvent("quit", {})
        end)
    end)
end

local function WaitForMC(lost)
    SetState("waiting", world.id, world.slot)
    local buttons = { { text = T.solo, cb = PlaySolo } }
    if lost then
        table.insert(buttons, 1, { text = T.save_quit, cb = SaveAndQuit })
    end
    ShowDialog(lost and T.lost_title or T.wait_title, lost and T.lost_text or T.wait_text, buttons)
end

-- 这个世界（森林、洞穴第几层、海难……）在 MC 里的原点：第一次配对时取饥荒玩家当时站的位置
local function WorldKey()
    local ground = GetWorld()
    return (ground.prefab or "world") .. "_" .. tostring(ground.topology and ground.topology.level_number or 1)
end

local function Pair(player, info)
    world.id = info.id
    info.origins = info.origins or {}
    local key = WorldKey()
    if not info.origins[key] then
        local x, _, z = player.Transform:GetWorldPosition()
        info.origins[key] = { math.floor(x + .5), math.floor(z + .5) }
    end
    mcbridge.SetOrigin(info.origins[key][1], info.origins[key][2])
    SetSlotInfo(world.slot, info)
    WaitForMC(false)
end

-- 存档载入完成（AddSimPostInit）时调用：决定这个存档要不要等 MC
function M.OnWorldLoaded(player)
    local slot = SaveGameIndex:GetCurrentSaveSlot()
    world = { slot = slot }
    local info = SlotInfo(slot)
    local pending_id, pending_slot, pending_session = TakePending()
    if pending_id and pending_slot == slot and not (info and info.id and info.id ~= pending_id) then
        world.request_session = pending_session
        info = info or {}
        info.id = pending_id
    end
    if info and info.id then
        Pair(player, info)
    else
        PlaySolo()
    end
end

-- Front-end polling remains alive while the simulation is paused or the window is minimized.
local saving = false
local function SaveWorld(done)
    if saving then return end
    saving = true
    SetState("saving", world.id, world.slot)
    SetPause(true, "starvecraft")
    -- MC publishes final ownership before requesting save; paused simulation tasks cannot consume it.
    local inventory = require("starvecraft/inventory")
    inventory.Receive(require("starvecraft/channel").Read("mc_inventory.json"))
    inventory.Export()
    SaveGameIndex:SaveCurrent(function()
        saving = false
        SetPause(true, "starvecraft")
        done()
    end)
end

local function OnGame(error_screen)
    if not world or world.solo or not world.id then return end
    mcbridge.Update(world.id, mc.session)
    if (McAlive() or world.request_session == mc.session) and mc.phase == "closed"
        and (mc.mode == "test") == STARVECRAFT.DEV then
        SaveWorld(RequestShutdown)
        return
    end
    if McAlive() and mc.id == world.id and mc.phase == "saving" then
        if (state.phase ~= "saved" or state.detail ~= mc.session) and not saving then
            local session = mc.session
            SaveWorld(function() SetState("saved", world.id, world.slot, session) end)
        end
        return
    end
    if McAlive() and (mc.mode == "test") ~= STARVECRAFT.DEV then
        SetState("error", world.id, world.slot, "mode_mismatch")
        SetPause(true, "starvecraft")
        return
    end
    if error_screen then
        SetState("error", world.id, world.slot, "backend_script_error")
        SetPause(true, "starvecraft")
        return
    end
    if McAlive() and mc.phase == "want" and mc.id ~= world.id and not saving then
        SetState("switching", world.id, world.slot)
        SaveWorld(function()
            inGamePlay = false
            GetPlayer():PushEvent("quit", {})
        end)
        return
    end
    if saving then return end
    local mc_in = McAlive() and mc.id == world.id and mc.phase == "in" and mcbridge.Active(world.id, mc.session)
    if mc_in then
        CloseDialog()
        local paused = mcbridge.pose.paused or mcbridge.pose.dead
        SetState(paused and "paused" or "in", world.id, world.slot)
    elseif state.phase == "in" or state.phase == "paused" or state.phase == "saved" then
        if McAlive() and mc.phase == "idle" then
            SaveWorld(function() WaitForMC(true) end)
        else
            WaitForMC(true)
        end
    end
end

function M.PairId() return world and world.id or "-" end
function M.McSession() return mc.session or "-" end
function M.RefreshPlayer() ReadMC(); if world and world.id then mcbridge.Update(world.id, mc.session) end end
function M.Active()
    return state.phase == "in" and McAlive() and mc.id == M.PairId() and mc.phase == "in"
        and (mc.mode == "test") == STARVECRAFT.DEV
        and mcbridge.Active(M.PairId(), mc.session) and not mcbridge.pose.paused and not mcbridge.pose.dead
end
function M.Shutdown()
    if world and not world.solo then SaveWorld(RequestShutdown) else RequestShutdown() end
end

-- 当前存档是否在和 MC 一起玩（入侵中或在等 MC）
function M.Paired()
    return world ~= nil and world.id ~= nil and not world.solo
end

function M.Describe()
    return string.format("link=%s %s@%d mc=%s %s@%d alive=%s", state.phase, state.id, state.slot,
        mc.phase, mc.id, mc.slot or -1, tostring(McAlive()))
end

-- ------------------------------------------------------------ 每帧（前端更新，暂停时也跑）

function M.Update()
    local now = GetTimeReal()
    if now - last_poll < POLL_MS then
        return
    end
    last_poll = now
    if now - last_beat_time >= 1000 then
        last_beat_time = now
        beat = beat + 1
        SetState(state.phase, state.id, state.slot, state.detail)
    end
    ReadMC()
    local menu=TheFrontEnd:GetActiveScreen()
    if not TheFrontEnd:IsDisplayingError() and (world or (menu and menu.name=="MainScreen")) then
        if require("starvecraft/deletions").Poll(world and (world.id or ""),function()
            CloseDialog()
            SaveWorld(function() StartNextInstance({reset_action=RESET_ACTION.LOAD_FRONTEND,starvecraft_mode=STARVECRAFT.MODE}) end)
        end) then return end
    end
    local ok, request = pcall(require("json").decode, ReadFile("control.json") or "")
    if ok and type(request) == "table" and request.action == "quit" and request.ds_session == M.session
        and type(request.time) == "number" and math.abs(os.time() - request.time) < 15
        and not McAlive() then
        M.Shutdown()
        return
    end
    if world then
        OnGame(TheFrontEnd:IsDisplayingError())
    elseif TheFrontEnd:IsDisplayingError() then
        SetState("error", nil, nil, "backend_script_error")
    else
        OnMenu()
    end
    require("starvecraft/nativemap").Update(world~=nil and M.Paired() and McAlive()
        and mc.phase=="in" and mcbridge.Active(M.PairId(),mc.session) and not TheFrontEnd:IsDisplayingError(),mcbridge.pose)
    -- Native screens can change pause while opening/closing. Apply the paired world's final state last.
    -- This is the engine's SetPause/SetTimeScale path; wall-time polling and heartbeats keep running.
    if M.Paired() then SetPause(state.phase~="in", "starvecraft") end
end

function M.Install()
    local update = FrontEnd.Update
    FrontEnd.Update = function(self, dt)
        update(self, dt)
        M.Update()
    end
    SetState("menu")
end

return M
