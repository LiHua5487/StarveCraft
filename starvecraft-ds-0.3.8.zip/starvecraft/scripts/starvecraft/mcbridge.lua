-- Player state is read independently of rendering; coordinates retain the original bridge convention.
local json = require("json")
local M = { origin = { x = 0, z = 0 }, pose = nil }
local last_seq, last_session, last_change = nil, nil, -math.huge
function M.SetOrigin(x, z) M.origin.x, M.origin.z = x, z end
function M.Update(pair, session)
    local f = io.open(STARVECRAFT.MODROOT .. "devio/mc_player.json", "r")
    if f then
        local text = f:read("*a")
        f:close()
        local ok, p = pcall(json.decode, text)
        if ok and type(p) == "table" and p.version == 2 and p.pair == pair and p.session == session
            and type(p.seq) == "number" and type(p.x) == "number" and type(p.y) == "number"
            and type(p.z) == "number" and p.x == p.x and p.z == p.z and math.abs(p.x) < 1000000 and math.abs(p.z) < 1000000
            and type(p.yaw) == "number" and p.yaw == p.yaw and math.abs(p.yaw) < 1000000
            and p.y == p.y and math.abs(p.y) < 1000000 and p.seq >= 0 and p.seq == math.floor(p.seq)
            and type(p.paused) == "boolean" and type(p.dead) == "boolean"
            and type(p.health) == "number" and p.health >= 0 and p.health < 100000
            and type(p.max_health) == "number" and p.max_health > 0 and p.max_health < 100000 then
            if p.block_light ~= nil and (type(p.block_light) ~= "number" or p.block_light < 0 or p.block_light > 15) then
                return M.Active(pair, session)
            end
            if p.view_distance~=nil and (type(p.view_distance)~="number" or p.view_distance~=math.floor(p.view_distance)
                or p.view_distance<16 or p.view_distance>2048) then return M.Active(pair,session) end
            if p.interaction_range~=nil and (type(p.interaction_range)~="number" or p.interaction_range~=p.interaction_range
                or p.interaction_range<0 or p.interaction_range>1024) then return M.Active(pair,session) end
            if p.travel_ack~=nil and (type(p.travel_ack)~="number" or p.travel_ack<0 or p.travel_ack>9007199254740991
                or p.travel_ack~=math.floor(p.travel_ack)) then return M.Active(pair,session) end
            if p.moving~=nil and type(p.moving)~="boolean" then return M.Active(pair,session) end
            if p.scene_ack~=nil and (type(p.scene_ack)~="number" or p.scene_ack<0 or p.scene_ack>9007199254740991
                or p.scene_ack~=math.floor(p.scene_ack) or type(p.scene_session)~="string" or #p.scene_session>64) then return M.Active(pair,session) end
            if p.work_target~=nil and (type(p.work_target)~="number" or p.work_target<0 or p.work_target>9007199254740991
                or p.work_target~=math.floor(p.work_target)) then return M.Active(pair,session) end
            if p.work_item~=nil and (type(p.work_item)~="string" or #p.work_item>128 or not p.work_item:match("^[%w_%-]*$")) then return M.Active(pair,session) end
            if p.targetable ~= nil and type(p.targetable) ~= "boolean" then return M.Active(pair, session) end
            if p.food~=nil and (type(p.food)~="number" or p.food~=p.food or p.food<0 or p.food>20) then return M.Active(pair,session) end
            if p.hands~=nil then
                if type(p.hands)~="table" or #p.hands>2 then return M.Active(pair,session) end
                for _,spec in ipairs(p.hands) do
                    if type(spec)~="table" or type(spec.item_id)~="string" or #spec.item_id>64
                        or not spec.item_id:match("^[%w%-]+$") or type(spec.prefab)~="string"
                        or not spec.prefab:match("^[%w_]+$") then return M.Active(pair,session) end
                end
            end
            if p.equipment~=nil then
                if type(p.equipment)~="table" or #p.equipment>4 then return M.Active(pair,session) end
                for _,spec in ipairs(p.equipment) do
                    if type(spec)~="table" or type(spec.item_id)~="string" or #spec.item_id>64 or not spec.item_id:match("^[%w%-]+$")
                        or (spec.equip~="hands" and spec.equip~="head" and spec.equip~="body")
                        or (spec.mc_slot~=nil and (spec.mc_slot~="mainhand" and spec.mc_slot~="offhand" or spec.equip~="hands"))
                        or type(spec.prefab)~="string" or not spec.prefab:match("^[%w_]+$")
                        or (spec.count~=nil and (type(spec.count)~="number" or spec.count<1 or spec.count>6400 or spec.count~=math.floor(spec.count))) then return M.Active(pair,session) end
                end
            end
            if p.carried~=nil then
                local spec=p.carried
                if type(spec)~="table" or type(spec.item_id)~="string" or #spec.item_id>64
                    or not spec.item_id:match("^[%w%-]+$") or type(spec.prefab)~="string" or not spec.prefab:match("^[%w_]+$")
                    or type(spec.count)~="number" or spec.count<1 or spec.count>6400 or spec.count~=math.floor(spec.count) then return M.Active(pair,session) end
            end
            if p.activity~=nil then
                local a=p.activity
                if type(a)~="table" or type(a.token)~="string" or #a.token>64
                    or type(a.seq)~="number" or a.seq<0 or a.seq>9007199254740991 or a.seq~=math.floor(a.seq)
                    or type(a.move)~="boolean" or type(a.cancel)~="boolean" then return M.Active(pair,session) end
            end
            if p.map_open~=nil and (type(p.map_open)~="boolean" or type(p.map_token)~="string" or #p.map_token>64) then return M.Active(pair,session) end
            if p.map_input~=nil then
                if type(p.map_input)~="table" then return M.Active(pair,session) end
                for _,key in ipairs({"x","y","zoom","rotate","click"}) do
                    local n=p.map_input[key]
                    if type(n)~="number" or n~=n or math.abs(n)>10000000 then return M.Active(pair,session) end
                end
                if p.map_input.button~="" and p.map_input.button~="left" and p.map_input.button~="right" and p.map_input.button~="close" then return M.Active(pair,session) end
            end
            if p.blocked_attackers ~= nil then
                if type(p.blocked_attackers) ~= "table" then return M.Active(pair, session) end
                local count=0
                for id, value in pairs(p.blocked_attackers) do
                    count=count+1
                    if type(id) ~= "string" or not id:match("^%d+$") or value ~= true or count>512 then return M.Active(pair, session) end
                end
            end
            if p.session == last_session and last_seq and p.seq < last_seq then return M.Active(pair, session) end
            if p.seq ~= last_seq or p.session ~= last_session then
                last_seq, last_session, last_change = p.seq, p.session, GetTimeReal()
            end
            M.pose = p
        end
    end
    return M.Active(pair, session)
end
function M.Active(pair, session)
    return M.pose ~= nil and M.pose.pair == pair and M.pose.session == session and GetTimeReal() - last_change < 3000
end
function M.ToDS(x, y, z) return M.origin.x + x, y + 63, M.origin.z - z end
function M.ToMC(x, y, z) return x - M.origin.x, y - 63, M.origin.z - z end
return M
