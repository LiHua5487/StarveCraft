-- Native item identity and UI metadata; MC owns the inventory stacks.
local json = require("json")
local M = {}
function M.Path(path)
    return path and path:match("(images/[%w_/%-]+%.xml)$") or "images/inventoryimages.xml"
end
function M.Spec(prefab, recipe)
    local o={prefab=prefab, name=STRINGS.NAMES[string.upper(prefab)] or prefab,
        atlas=M.Path(recipe and recipe:GetAtlas() or GetInventoryItemAtlas(prefab .. ".tex")),
        image=recipe and recipe.image or prefab .. ".tex", count=1, max_stack=99}
    return o
end
function M.Describe(inst, skip_record)
    local store=require("starvecraft/inventory")
    if inst.sc_mc_item then
        local parcel=deepcopy(inst.sc_mc_item)
        parcel.count=1
        parcel.native=true;parcel.managed=true;parcel.item_id=store.Id(inst)
        parcel.origin=inst.sc_mc_origin
        return parcel
    end
    local o=M.Spec(inst.prefab)
    local inv=inst.components.inventoryitem
    o.name=inst:GetDisplayName()
    o.image=inv:GetImage()
    o.atlas=M.Path(inv:GetAtlas())
    o.count=inst.components.stackable and inst.components.stackable:StackSize() or 1
    o.max_stack=inst.components.stackable and 99 or 1
    if inst.components.stackable then o.native_stack_max=inst.components.stackable.maxsize end
    if not skip_record then o.record=inst:GetSaveRecord() end
    o.native=true;o.managed=true;o.item_id=store.Id(inst);o.origin=inst.sc_mc_origin
    if inst.sc_mc_origin=="mc" then o.mc_condition_total=inst.sc_mc_condition_total or 0 end
    if inst.sc_mc_prefab==inst.prefab then o.mc_stack=inst.sc_mc_stack end
    if inst.components.perishable then o.freshness=inst.components.perishable:GetPercent() end
    if inst.components.fueled then o.fuel=inst.components.fueled:GetPercent() end
    if inst.components.armor or inst.components.resistance then o.armor=true end
    local player=GetPlayer()
    o.edible=inst.components.edible~=nil and player.components.eater:CanEat(inst) or false
    local picker=player and player.components.playeractionpicker
    if picker then
        local function useful(actions)
            for _,action in ipairs(actions or {}) do
                if action.action~=ACTIONS.DROP and action.action~=ACTIONS.EQUIP and action.action~=ACTIONS.UNEQUIP
                    and action.action~=ACTIONS.WALKTO and action.action~=ACTIONS.LOOKAT then return true end
            end
            return false
        end
        o.inventory_use=useful(picker:GetInventoryActions(inst,true)) or useful(picker:GetInventoryActions(inst,false))
        o.point_use=inst.components.deployable~=nil or useful(picker:GetPointActions(player:GetPosition(),inst,true)) or useful(picker:GetPointActions(player:GetPosition(),inst,false))
    end
    local pose=require("starvecraft/mcbridge").pose
    if pose and pose.carried and pose.carried.item_id==o.item_id then
        o.item_targets={}
        for id in pairs(store.entries) do
            local target=store.Find(id)
            if target and target~=inst and require("starvecraft/actions").Item(target,inst) then table.insert(o.item_targets,id) end
        end
        table.sort(o.item_targets)
    end
    local equip=inst.components.equippable
    if equip or inst.components.tool or inst.components.weapon then
        o.equip=equip and tostring(inst.sc_mc_native_equip_slot or equip.equipslot) or nil
        if equip then o.walkspeed=equip.walkspeedmult or 1 end
        o.actions={}
        for action in pairs(inst.components.tool and inst.components.tool.action or {}) do o.actions[action.id]=true end
        local weapon=inst.components.weapon
        if weapon and type(weapon.damage)=="number" then o.damage=weapon.damage end
    end
    local condition=inst.components.finiteuses or inst.components.armor or inst.components.fueled
    if condition and condition.GetPercent then o.condition=condition:GetPercent() end
    return o
end

local equivalents={}
function M.Equivalent(prefab)
    if not equivalents[prefab] then
        -- Query each native definition once; these probes never become player items.
        local probe=assert(SpawnPrefab(prefab),"missing native equivalent "..prefab)
        local ok,spec=pcall(M.Describe,probe,true)
        probe:Remove()
        if not ok then error(spec) end
        for _,key in ipairs({"item_id","managed","origin","revision","mc_holder","record"}) do spec[key]=nil end
        equivalents[prefab]=spec
    end
    return deepcopy(equivalents[prefab])
end

-- A reserved building is an inventory claim, not an already placed structure.
function M.HookParcel(inst)
    local save,load=inst.OnSave,inst.OnLoad
    function inst:OnSave(data,...)
        local result=save and save(self,data,...)
        data.starvecraft_item=self.sc_mc_item
        return result
    end
    function inst:OnLoad(data,...)
        if load then load(self,data,...) end
        if data and data.starvecraft_item then M.Parcel(self,data.starvecraft_item) end
    end
end
function M.Parcel(inst,spec)
    inst.sc_mc_item=deepcopy(spec)
    inst.recipetouse=nil
    inst:RemoveComponent("teacher")
    if not inst.components.named then inst:AddComponent("named") end
    inst.components.named:SetName(spec.name or spec.prefab)
end
function M.ReturnDrop(request)
    if type(request)~="table" or type(request.id)~="string" or #request.id>64
        or not request.id:match("^[%w%-]+$") or type(request.item)~="table" then return end
    local receipts=GetPlayer().components.builder.sc_receipts
    local function reply(result) require("starvecraft/channel").Send("ground_result "..json.encode(result)) end
    if receipts[request.id] then reply(receipts[request.id]);return end
    local spec,count=request.item,tonumber(request.count)
    local x,z=tonumber(request.x),tonumber(request.z)
    if type(spec.prefab)~="string" or not spec.prefab:match("^[%w_]+$")
        or not count or count<1 or count>6400 or count~=math.floor(count)
        or not x or not z or math.abs(x)>1000000 or math.abs(z)>1000000 then return end
    local dx,_,dz=require("starvecraft/mcbridge").ToDS(x,0,z)
    local store=require("starvecraft/inventory")
    local equipment=require("starvecraft/equipment")
    local inst
    local ok,err=pcall(function()
        spec=deepcopy(spec);spec.count=count;spec.import_id=request.id
        inst=equipment.Acquire(spec)
        assert(inst and inst.components.inventoryitem,"native drop reference is unavailable")
        equipment.Detach(inst);inst.persists=true
        GetPlayer().components.inventory:DropItem(inst,true,true,Point(dx,0,dz))
    end)
    if not ok then
        if inst and inst:IsValid() then store.Keep(inst) end
        print("[StarveCraft] Native drop failed:",err)
        return
    end
    local result={id=request.id,ok=true,ground=true}
    receipts[request.id]=result
    reply(result)
end
function M.Speech(inst)
    local talker=inst.components.talker
    local text=talker and talker.widget and talker.widget.text
    return text and text:GetString() or ""
end
local last_widget, last_text
function M.PlayerSpeech(player)
    local talker=player.components.talker
    local widget=talker and talker.widget
    local text=M.Speech(player)
    if text ~= "" and (widget ~= last_widget or text ~= last_text) then
        require("starvecraft/channel").Send("chat " .. json.encode(text))
    end
    last_widget, last_text=widget, text
end
return M
