param([Parameter(Mandatory=$true)][string]$Directory,[Parameter(Mandatory=$true)][string]$Token,[switch]$CompileOnly)
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Utility\Microsoft.PowerShell.Utility.psd1')
try {
    if ($Token -notmatch '^[a-f0-9-]{36}$') { throw 'Invalid map session' }
    $source=Join-Path $PSScriptRoot 'Capture.cs'
    $hasher=[Security.Cryptography.SHA256]::Create()
    try { $hash=[BitConverter]::ToString($hasher.ComputeHash([IO.File]::ReadAllBytes($source))).Replace('-','').Substring(0,16) }
    finally { $hasher.Dispose() }
    $library=Join-Path $Directory "MapCapture-$hash.dll"
    if (-not (Test-Path -LiteralPath $library)) {
        $framework=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
        $references=@('System.dll','System.Core.dll','System.Drawing.dll','System.Web.Extensions.dll',
            'System.Runtime.dll','System.Runtime.InteropServices.WindowsRuntime.dll','System.Runtime.WindowsRuntime.dll') |
            ForEach-Object { Join-Path $framework $_ }
        $references += @('Windows.Foundation.winmd','Windows.Graphics.winmd','Windows.Storage.winmd') |
            ForEach-Object { Join-Path (Join-Path $env:WINDIR 'System32\WinMetadata') $_ }
        $compile=@('/nologo','/target:library',('/out:'+$library)) + @($references | ForEach-Object { '/reference:'+$_ }) + @($source)
        & (Join-Path $framework 'csc.exe') @compile
        if ($LASTEXITCODE -ne 0) { throw 'Native map helper compilation failed' }
    }
    Add-Type -Path $library
    if ($CompileOnly) { return }
    $game=[Diagnostics.Process]::GetProcessesByName('dontstarve_steam') | Select-Object -First 1
    if (-not $game) { throw 'The native backend is not running' }
    [StarveCraft.NativeMap.Capture]::Run($Directory,$Token,$game.MainWindowHandle.ToInt64())
} catch {
    [IO.File]::WriteAllText((Join-Path $Directory "map_$Token.error"),($_ | Out-String))
    throw
}
