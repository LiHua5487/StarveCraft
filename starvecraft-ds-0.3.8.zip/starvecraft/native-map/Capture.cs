using System;
using System.IO;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using Windows.Graphics.Capture;
using Windows.Graphics.DirectX;
using Windows.Graphics.DirectX.Direct3D11;
using Windows.Graphics.Imaging;
using Windows.Storage.Streams;

namespace StarveCraft.NativeMap {
    // Capture only this game's native map. Pixels cross the bridge as a normal PNG file.
    public static class Capture {
        [ComImport, Guid("3628e81b-3cac-4c60-b7f4-23ce0e0c3356"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        interface ICaptureItemInterop {
            void CreateForWindow(IntPtr window, ref Guid iid, out IntPtr item);
            void CreateForMonitor(IntPtr monitor, ref Guid iid, out IntPtr item);
        }
        [DllImport("d3d11.dll", PreserveSig=true)] static extern int D3D11CreateDevice(IntPtr adapter,int driver,IntPtr software,uint flags,IntPtr levels,uint levelCount,uint version,out IntPtr device,out int level,out IntPtr context);
        [DllImport("d3d11.dll")] static extern int CreateDirect3D11DeviceFromDXGIDevice(IntPtr device,out IntPtr result);
        [DllImport("user32.dll")] static extern bool IsWindow(IntPtr window);
        [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(IntPtr context);
        [DllImport("user32.dll")] static extern bool IsIconic(IntPtr window);
        [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr window,int mode);
        [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr window,out RECT rect);
        [DllImport("user32.dll")] static extern bool ClientToScreen(IntPtr window,ref POINT point);
        [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr window,IntPtr order,int x,int y,int w,int h,uint flags);
        [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr window,int attribute,out RECT rect,int size);
        [StructLayout(LayoutKind.Sequential)] struct RECT { public int left,top,right,bottom; }
        [StructLayout(LayoutKind.Sequential)] struct POINT { public int x,y; }
        static readonly JavaScriptSerializer Json=new JavaScriptSerializer();
        static Dictionary<string,object> Read(string path) {
            try { return Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(path)); } catch { return null; }
        }
        static bool Matches(Dictionary<string,object> state,string token) {
            return state!=null && state.ContainsKey("map_token") && Convert.ToString(state["map_token"])==token;
        }
        sealed class FrameWriter : IDisposable {
            Windows.Storage.Streams.Buffer buffer;
            byte[] pixels;
            Bitmap image;
            public void Save(SoftwareBitmap software,IntPtr window,string path) {
                int w=software.PixelWidth,h=software.PixelHeight,length=checked(w*h*4);
                if(pixels==null || pixels.Length!=length) {buffer=new Windows.Storage.Streams.Buffer((uint)length);pixels=new byte[length];}
                software.CopyToBuffer(buffer);
                using(var reader=DataReader.FromBuffer(buffer)) reader.ReadBytes(pixels);
                RECT client,bounds;POINT origin=new POINT();
                GetClientRect(window,out client);ClientToScreen(window,ref origin);
                DwmGetWindowAttribute(window,9,out bounds,Marshal.SizeOf(typeof(RECT)));
                var crop=Rectangle.Intersect(new Rectangle(origin.x-bounds.left,origin.y-bounds.top,client.right,client.bottom),new Rectangle(0,0,w,h));
                if(crop.Width<1 || crop.Height<1) throw new InvalidOperationException("Empty native-map client area");
                if(image==null || image.Width!=crop.Width || image.Height!=crop.Height) {
                    if(image!=null) image.Dispose();image=new Bitmap(crop.Width,crop.Height,PixelFormat.Format32bppArgb);
                }
                var data=image.LockBits(new Rectangle(0,0,crop.Width,crop.Height),ImageLockMode.WriteOnly,PixelFormat.Format32bppArgb);
                try {
                    for(int y=0;y<crop.Height;y++) Marshal.Copy(pixels,((crop.Y+y)*w+crop.X)*4,IntPtr.Add(data.Scan0,y*data.Stride),crop.Width*4);
                } finally {image.UnlockBits(data);}
                image.Save(path+".pending",ImageFormat.Png);
                if(File.Exists(path)) File.Replace(path+".pending",path,null);else File.Move(path+".pending",path);
            }
            public void Dispose() {if(image!=null) image.Dispose();}
        }
        static Direct3D11CaptureFrame Latest(Direct3D11CaptureFramePool pool) {
            Direct3D11CaptureFrame latest=null,next;
            while((next=pool.TryGetNextFrame())!=null) {if(latest!=null) latest.Dispose();latest=next;}
            return latest;
        }
        public static void Run(string directory,string token,long handle) {
            SetProcessDpiAwarenessContext(new IntPtr(-4));
            IntPtr window=new IntPtr(handle);
            if(!GraphicsCaptureSession.IsSupported()) throw new NotSupportedException("Windows Graphics Capture is unavailable");
            string restoreFlag=Path.Combine(directory,"map_window_"+handle+".minimized");
            bool minimized=IsIconic(window) || File.Exists(restoreFlag);
            IntPtr nativeDevice=IntPtr.Zero,nativeContext=IntPtr.Zero,dxgi=IntPtr.Zero,inspectable=IntPtr.Zero,itemPointer=IntPtr.Zero;
            IDirect3DDevice device=null;
            Direct3D11CaptureFramePool pool=null;GraphicsCaptureSession session=null;
            try {
                int feature;
                Marshal.ThrowExceptionForHR(D3D11CreateDevice(IntPtr.Zero,1,IntPtr.Zero,0x20,IntPtr.Zero,0,7,out nativeDevice,out feature,out nativeContext));
                var iid=new Guid("54ec77fa-1377-44e6-8c32-88fd5f44c84c");
                Marshal.ThrowExceptionForHR(Marshal.QueryInterface(nativeDevice,ref iid,out dxgi));
                Marshal.ThrowExceptionForHR(CreateDirect3D11DeviceFromDXGIDevice(dxgi,out inspectable));
                device=(IDirect3DDevice)Marshal.GetObjectForIUnknown(inspectable);
                var interop=(ICaptureItemInterop)WindowsRuntimeMarshal.GetActivationFactory(typeof(GraphicsCaptureItem));
                iid=new Guid("79c3f95b-31f7-4ec2-a464-632ef5d30760");
                interop.CreateForWindow(window,ref iid,out itemPointer);
                var item=(GraphicsCaptureItem)Marshal.GetObjectForIUnknown(itemPointer);
                if(IsIconic(window)) {File.WriteAllText(restoreFlag,"1");ShowWindow(window,4);SetWindowPos(window,new IntPtr(1),0,0,0,0,0x13);}
                var size=item.Size;
                for(int attempt=0;(size.Width<1 || size.Height<1) && attempt<40;attempt++) {Thread.Sleep(25);size=item.Size;}
                pool=Direct3D11CaptureFramePool.CreateFreeThreaded(device,DirectXPixelFormat.B8G8R8A8UIntNormalized,2,size);
                session=pool.CreateCaptureSession(item);
                session.IsCursorCaptureEnabled=false;
                session.StartCapture();
                string player=Path.Combine(directory,"mc_player.json"),statePath=Path.Combine(directory,"native_map_state.json");
                string output=Path.Combine(directory,"map_"+token+".png");
                bool ready=false;
                using(var writer=new FrameWriter())
                while(IsWindow(window)) {
                    long cycle=Stopwatch.GetTimestamp();
                    var actor=Read(player);
                    if(actor==null) {Thread.Sleep(50);continue;}
                    if(!Matches(actor,token) || !actor.ContainsKey("map_open") || !(bool)actor["map_open"]
                        || DateTime.UtcNow-File.GetLastWriteTimeUtc(player)>TimeSpan.FromSeconds(4)) break;
                    var state=Read(statePath);
                    if(!Matches(state,token) || !state.ContainsKey("ready") || !(bool)state["ready"]
                        || DateTime.UtcNow-File.GetLastWriteTimeUtc(statePath)>TimeSpan.FromSeconds(3)) {Thread.Sleep(50);continue;}
                    if(!ready) {
                        Direct3D11CaptureFrame old;
                        while((old=pool.TryGetNextFrame())!=null) old.Dispose();
                        ready=true;Thread.Sleep(100);continue;
                    }
                    using(var frame=Latest(pool)) {
                        if(frame!=null) {
                            var next=frame.ContentSize;
                            var operation=SoftwareBitmap.CreateCopyFromSurfaceAsync(frame.Surface);
                            while(operation.Status==Windows.Foundation.AsyncStatus.Started) Thread.Sleep(1);
                            using(var bitmap=operation.GetResults()) {
                                try {writer.Save(bitmap,window,output);} catch(IOException) { }
                            }
                            operation.Close();
                            if(next.Width!=size.Width || next.Height!=size.Height) {size=next;pool.Recreate(device,DirectXPixelFormat.B8G8R8A8UIntNormalized,2,size);}
                        }
                    }
                    // About 30 FPS including readback/PNG work; never add the old 80 ms delay after that work.
                    int remaining=33-(int)((Stopwatch.GetTimestamp()-cycle)*1000/Stopwatch.Frequency);
                    Thread.Sleep(Math.Max(1,remaining));
                }
            } finally {
                if(session!=null) session.Dispose();if(pool!=null) pool.Dispose();if(device!=null) device.Dispose();
                foreach(IntPtr p in new[]{itemPointer,inspectable,dxgi,nativeContext,nativeDevice}) if(p!=IntPtr.Zero) Marshal.Release(p);
                var actor=Read(Path.Combine(directory,"mc_player.json"));
                if(minimized && IsWindow(window) && (actor==null || !actor.ContainsKey("map_open") || !(bool)actor["map_open"])) {
                    ShowWindow(window,6);File.Delete(restoreFlag);
                }
                try {File.Delete(Path.Combine(directory,"map_"+token+".png"));} catch(IOException) { }
            }
        }
    }
}
