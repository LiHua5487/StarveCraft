-- StarveCraft：MC 入侵饥荒（饥荒侧）
--   Minecraft 客户端（mcmod/）统一绘制原版饥荒精灵、地面、MC 方块和 HUD；
--   两边用各自的存档界面，存档两两配对，进其中一边的存档另一边自动跟上（starvecraft/link）；
--   这边负责让饥荒玩家跟着 MC 角色位置走（starvecraft/invasion、starvecraft/mcbridge），
--   并和 MC 互通世界：树、石头、生物的替身，砍/挖/打/采，掉落与受伤，昼夜（starvecraft/mcworld）；
--   MC 放的方块挡住饥荒的怪、MC 的火把照亮饥荒（starvecraft/mcblocks）。

local G = GLOBAL
local require = G.require

G.STARVECRAFT = {
    MODROOT = MODROOT,
}
local mode = require("starvecraft/mode")
local DEV = mode.testing
PrefabFiles={"sc_itemvault","sc_itemholder"}
G.STARVECRAFT.DEV = DEV
G.STARVECRAFT.MODE = mode.name
require("starvecraft/saves").Install(DEV and "starvecraft_unified_" or "starvecraft_play_")
require("starvecraft/animtrack").Install()
require("starvecraft/nativeui").Install()
AddClassPostConstruct("widgets/widget",require("starvecraft/nativeui").HookWidget)

local mcworld = require("starvecraft/mcworld")
mcworld.InstallLights()
require("starvecraft/surface").Observe()
local link = require("starvecraft/link")
link.Install()
if DEV then require("starvecraft/test/entry").Install() end

AddPrefabPostInit("blueprint", require("starvecraft/items").HookParcel)
AddComponentPostInit("builder", require("starvecraft/crafting").HookBuilder)
AddComponentPostInit("inventoryitem", require("starvecraft/inventory").HookItem)
AddComponentPostInit("equippable", require("starvecraft/equipment").HookEquippable)
AddClassPostConstruct("widgets/inventorybar", require("starvecraft/equipment").HookInventoryBar)
AddComponentPostInit("seasonmanager", require("starvecraft/weather").HookSeason)
AddComponentPostInit("container", require("starvecraft/nativeui").HookContainer)
AddComponentPostInit("combat", require("starvecraft/invasion").HookCombat)
AddComponentPostInit("teleporter", require("starvecraft/travel").Hook)

AddSimPostInit(function(player)
    local invasion = require("starvecraft/invasion")
    require("starvecraft/activity").Install(player)
    require("starvecraft/surface").Install(player)
    invasion.Install(player)
    require("starvecraft/inventory").Install(player)
    require("starvecraft/equipment").Install(player)
    link.OnWorldLoaded(player)
    mcworld.Install(player, invasion.IsActive)
    require("starvecraft/mcblocks").Install(player, invasion.IsActive)
    if DEV then
        require("starvecraft/test/entry").Start(player)
    end
end)
